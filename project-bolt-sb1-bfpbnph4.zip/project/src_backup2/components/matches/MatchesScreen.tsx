import { useMatchStore } from '../../store/matches';
import { useMatchPolling } from '../../hooks/useMatchPolling';
import { isApiKeyConfigured } from '../../services/config';
import { TURKISH_LEAGUE_IDS } from '../../services/config';
import { toIstanbulDate, todayIstanbul, dateSectionLabel } from '../../services/dateUtils';
import { MatchCard } from './MatchCard';
import type { Match } from '../../types';

/** League display order */
const LEAGUE_ORDER: Record<number, number> = {
  203: 1,
  204: 2,
  205: 3,
  206: 4,
  207: 5,
};

const LEAGUE_LABELS: Record<number, string> = {
  203: 'Trendyol Süper Lig',
  204: 'Trendyol 1. Lig',
  205: 'TFF 2. Lig',
  206: 'TFF 3. Lig',
  207: 'Ziraat Türkiye Kupası',
};

function isLive(m: Match) {
  return m.status === 'live' || m.status === 'halftime';
}

function matchPriority(m: Match): number {
  if (isLive(m)) return 0;
  if (m.status === 'scheduled') return 1;
  return 2;
}

function sortMatches(matches: Match[]): Match[] {
  return [...matches].sort((a, b) => {
    const pa = matchPriority(a), pb = matchPriority(b);
    if (pa !== pb) return pa - pb;
    if (pa === 0) return b.minute - a.minute;
    return (a.kickoffTime ?? '').localeCompare(b.kickoffTime ?? '');
  });
}

/** Group matches: competition → date → [Match] */
function groupMatches(matches: Match[]): Map<number, Map<string, Match[]>> {
  const competitionMap = new Map<number, Map<string, Match[]>>();

  for (const m of matches) {
    const lid = TURKISH_LEAGUE_IDS.includes(m.leagueId)
      ? m.leagueId
      : 0;

    if (!competitionMap.has(lid)) competitionMap.set(lid, new Map());
    const dateMap = competitionMap.get(lid)!;

    const dateKey = m.kickoffTime ? toIstanbulDate(m.kickoffTime) : todayIstanbul();
    if (!dateMap.has(dateKey)) dateMap.set(dateKey, []);
    dateMap.get(dateKey)!.push(m);
  }

  // Sort leagues
  const sorted = new Map(
    [...competitionMap.entries()].sort(
      ([a], [b]) => (LEAGUE_ORDER[a] ?? 99) - (LEAGUE_ORDER[b] ?? 99)
    )
  );

  // Sort dates within each league and matches within each date
  for (const [, dateMap] of sorted) {
    const sortedDates = new Map(
      [...dateMap.entries()].sort(([a], [b]) => a.localeCompare(b))
    );
    // Sort matches within each date: live → upcoming → finished
    for (const [dateKey, arr] of sortedDates) {
      sortedDates.set(dateKey, sortMatches(arr));
    }
    // replace in-place
    dateMap.clear();
    for (const [k, v] of sortedDates) dateMap.set(k, v);
  }

  return sorted;
}

interface MatchesScreenProps {
  onMatchClick: (match: Match) => void;
}

export function MatchesScreen({ onMatchClick }: MatchesScreenProps) {
  const { matches, loading, error } = useMatchStore();
  const { refresh } = useMatchPolling();
  const noApiKey = !isApiKeyConfigured();
  const today = todayIstanbul();

  const liveCount = matches.filter(m =>
    m.statusShort === '1H' || m.statusShort === '2H' || m.statusShort === 'ET' || m.statusShort === 'P'
  ).length;

  if (loading && matches.length === 0) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 16 }}>
        <div style={{
          width: 40, height: 40, borderRadius: '50%',
          border: '3px solid var(--divider)',
          borderTopColor: 'var(--primary)',
          animation: 'spin 0.8s linear infinite',
        }} />
        <span style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Maçlar yükleniyor...</span>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (error && matches.length === 0) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 12, padding: 32, textAlign: 'center' }}>
        <svg width={48} height={48} viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" strokeWidth={1.5}>
          <path d="M1 1l22 22M16.72 11.06A10.94 10.94 0 0 1 19 12.55M5 12.55a10.94 10.94 0 0 1 5.17-2.39M10.71 5.05A16 16 0 0 1 22.56 9M1.42 9a15.91 15.91 0 0 1 4.7-2.88M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/>
        </svg>
        <span style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-secondary)' }}>Maçlar yüklenemedi</span>
        <span style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>{error}</span>
        <button onClick={refresh} style={{
          background: 'var(--primary)', color: '#fff', border: 'none', borderRadius: 10,
          padding: '10px 20px', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins',
        }}>
          Tekrar Dene
        </button>
      </div>
    );
  }

  const grouped = groupMatches(matches);

  return (
    <div className="scroll-area" style={{ padding: '0 14px' }}>
      {/* Demo banner */}
      {noApiKey && (
        <div style={{
          background: 'rgba(249,168,37,0.10)', border: '1px solid rgba(249,168,37,0.35)',
          borderRadius: 12, padding: '9px 13px', margin: '10px 0',
          display: 'flex', alignItems: 'flex-start', gap: 10,
        }}>
          <span style={{ fontSize: 17, lineHeight: 1.4 }}>🔑</span>
          <div>
            <div style={{ fontSize: 12.5, fontWeight: 700, color: '#b07800' }}>Demo Modu — Gerçek veri değil</div>
            <div style={{ fontSize: 11.5, color: 'var(--text-secondary)', marginTop: 2, lineHeight: 1.4 }}>
              Gerçek verileri görmek için .env dosyasına VITE_API_FOOTBALL_KEY ekleyin.
            </div>
          </div>
        </div>
      )}

      {matches.length === 0 && !loading && (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, marginTop: 80, textAlign: 'center' }}>
          <svg width={64} height={64} viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" strokeWidth={1.2}>
            <circle cx="12" cy="12" r="10"/>
            <polyline points="12 6 12 12 16 14"/>
          </svg>
          <span style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-secondary)' }}>Bugün maç yok</span>
          <span style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>Maçlar başladığında burada görünecek</span>
        </div>
      )}

      {[...grouped.entries()].map(([leagueId, dateMap]) => {
        const leagueLabel = LEAGUE_LABELS[leagueId] ?? `Lig ${leagueId}`;
        const allMatches = [...dateMap.values()].flat();
        const hasLive = allMatches.some(isLive);

        return (
          <div key={leagueId} style={{ marginBottom: 4 }}>
            {/* Competition header */}
            <div style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '14px 2px 8px',
            }}>
              <div style={{
                width: 4, height: 18, background: 'var(--primary)',
                borderRadius: 2, flexShrink: 0,
              }} />
              <span style={{ fontSize: 14.5, fontWeight: 700, color: 'var(--text)', flex: 1 }}>
                {leagueLabel}
              </span>
              {hasLive && (
                <span style={{
                  display: 'flex', alignItems: 'center', gap: 4,
                  fontSize: 11, fontWeight: 700, color: 'var(--primary)',
                }}>
                  <span className="live-dot" style={{ width: 6, height: 6 }} />
                  CANLI
                </span>
              )}
            </div>

            {/* Date sections within competition */}
            {[...dateMap.entries()].map(([dateKey, dayMatches]) => {
              const label = dateSectionLabel(dateKey);
              const isToday = dateKey === today;

              return (
                <div key={dateKey}>
                  {/* Date label — only show if not today or if there are multiple dates */}
                  {(!isToday || dateMap.size > 1) && (
                    <div style={{
                      fontSize: 11.5, fontWeight: 600,
                      color: 'var(--text-tertiary)',
                      padding: '4px 2px 6px',
                      letterSpacing: 0.3,
                    }}>
                      {label}
                    </div>
                  )}
                  {dayMatches.map((m, i) => (
                    <MatchCard
                      key={m.id}
                      match={m}
                      onClick={() => onMatchClick(m)}
                      index={i}
                    />
                  ))}
                </div>
              );
            })}
          </div>
        );
      })}

      {/* Live counter for internal tracking — not visible, but passed up to AppBar */}
      <div data-live-count={liveCount} style={{ display: 'none' }} />

      <div style={{ height: 24 }} />
    </div>
  );
}
