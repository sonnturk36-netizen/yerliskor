/** Official YerliSkor brand icon — vector football emblem */
export function YerliSkorIcon({ size = 36 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ display: 'block', flexShrink: 0 }}
    >
      {/* Red background circle */}
      <circle cx="50" cy="50" r="50" fill="#D50000"/>

      {/* Football pentagon/hexagon pattern */}
      {/* Central pentagon (black) */}
      <polygon
        points="50,30 63,40 58,55 42,55 37,40"
        fill="#111111"
      />
      {/* Surrounding patches (white) */}
      <polygon points="50,18 58,24 63,40 50,30 37,40 42,24" fill="white" opacity="0.9"/>
      <polygon points="63,40 76,38 78,52 66,58 58,55" fill="white" opacity="0.9"/>
      <polygon points="58,55 66,58 60,72 50,74 44,68" fill="white" opacity="0.9"/>
      <polygon points="42,55 44,68 34,74 24,68 30,55" fill="white" opacity="0.9"/>
      <polygon points="37,40 30,55 22,52 24,38 36,38" fill="white" opacity="0.9"/>

      {/* YS text at bottom */}
      <text
        x="50"
        y="92"
        textAnchor="middle"
        fontFamily="'Poppins', 'Arial Black', sans-serif"
        fontWeight="800"
        fontSize="16"
        fill="white"
        letterSpacing="1"
      >
        YS
      </text>
    </svg>
  );
}

interface BrandLogoProps {
  size?: number;
  textSize?: number;
}

export function BrandLogo({ size = 36, textSize }: BrandLogoProps) {
  const fs = textSize ?? Math.round(size * 0.60);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{
        width: size,
        height: size,
        borderRadius: size * 0.22,
        overflow: 'hidden',
        boxShadow: '0 2px 8px rgba(213,0,0,0.30)',
        flexShrink: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}>
        <YerliSkorIcon size={size} />
      </div>
      <span style={{ fontSize: fs, fontWeight: 700, letterSpacing: -0.3, lineHeight: 1, whiteSpace: 'nowrap' }}>
        <span style={{ color: 'var(--text)' }}>Yerli</span>
        <span style={{ color: 'var(--primary)' }}>Skor</span>
      </span>
    </div>
  );
}
