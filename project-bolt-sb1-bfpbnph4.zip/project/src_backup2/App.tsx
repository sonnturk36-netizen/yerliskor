import { useState, useEffect } from 'react';
import { useMatchStore } from './store/matches';
import { useNotificationStore } from './store/notifications';
import { useMatchPolling } from './hooks/useMatchPolling';
import { AppBar } from './components/layout/AppBar';
import { YerliSkorIcon } from './components/layout/BrandLogo';
import { BottomNav } from './components/layout/BottomNav';
import { MatchesScreen } from './components/matches/MatchesScreen';
import { MatchDetailsScreen } from './components/match-details/MatchDetailsScreen';
import { NotificationsScreen } from './components/notifications/NotificationsScreen';
import type { Match } from './types';

type Tab = 'matches' | 'notifications';

// Splash screen
function SplashScreen({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 1800);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'var(--bg)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      gap: 20, zIndex: 100,
    }}
    className="animate-fade-in"
    >
      <div className="animate-scale-in" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20 }}>
        <div style={{
          width: 80, height: 80,
          borderRadius: 22,
          overflow: 'hidden',
          boxShadow: '0 6px 24px rgba(213,0,0,0.35)',
        }}>
          <YerliSkorIcon size={80} />
        </div>
        <div>
          <div style={{ fontSize: 34, fontWeight: 700, textAlign: 'center', letterSpacing: -0.5 }}>
            <span style={{ color: 'var(--text)' }}>Yerli</span>
            <span style={{ color: 'var(--primary)' }}>Skor</span>
          </div>
          <div style={{ fontSize: 13, color: 'var(--text-secondary)', textAlign: 'center', marginTop: 6 }}>
            Türk Futbolunun Skor Uygulaması
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [splash, setSplash] = useState(true);
  const [tab, setTab] = useState<Tab>('matches');
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);

  const matches = useMatchStore(s => s.matches);
  const unreadCount = useNotificationStore(s => s.unreadCount());

  useMatchPolling();

  // Only count truly-in-play matches (1H, 2H, ET, P) — not HT which is break time
  const liveCount = matches.filter(m =>
    m.statusShort === '1H' || m.statusShort === '2H' ||
    m.statusShort === 'ET' || m.statusShort === 'P' || m.statusShort === 'LIVE'
  ).length;

  if (splash) {
    return <SplashScreen onDone={() => setSplash(false)} />;
  }

  if (selectedMatch) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100dvh' }}>
        <MatchDetailsScreen
          match={selectedMatch}
          onBack={() => setSelectedMatch(null)}
        />
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100dvh' }}>
      <AppBar liveCount={liveCount} />
      <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: tab === 'matches' ? 'flex' : 'none', flex: 1, flexDirection: 'column', overflow: 'hidden' }}>
          <MatchesScreen onMatchClick={setSelectedMatch} />
        </div>
        <div style={{ display: tab === 'notifications' ? 'flex' : 'none', flex: 1, flexDirection: 'column', overflow: 'hidden' }}>
          <NotificationsScreen />
        </div>
      </div>
      <BottomNav activeTab={tab} onTabChange={setTab} unreadCount={unreadCount} />
    </div>
  );
}
