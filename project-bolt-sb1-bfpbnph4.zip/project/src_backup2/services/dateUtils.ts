const TZ = 'Europe/Istanbul';

const TR_MONTHS = [
  'Ocak','Şubat','Mart','Nisan','Mayıs','Haziran',
  'Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık',
];

/** Returns YYYY-MM-DD string in Istanbul timezone */
export function toIstanbulDate(iso: string): string {
  const d = new Date(iso);
  const parts = new Intl.DateTimeFormat('tr-TR', {
    timeZone: TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(d);
  const get = (type: string) => parts.find(p => p.type === type)?.value ?? '';
  return `${get('year')}-${get('month')}-${get('day')}`;
}

/** Returns today's YYYY-MM-DD in Istanbul timezone */
export function todayIstanbul(): string {
  return toIstanbulDate(new Date().toISOString());
}

/** Turkish section label for a date key (YYYY-MM-DD) */
export function dateSectionLabel(dateKey: string): string {
  const today = todayIstanbul();
  const yesterday = offsetDate(today, -1);
  const tomorrow = offsetDate(today, +1);

  if (dateKey === today) return 'Bugün';
  if (dateKey === yesterday) return 'Dün';
  if (dateKey === tomorrow) return 'Yarın';

  // Parse YYYY-MM-DD
  const [, mm, dd] = dateKey.split('-').map(Number);
  return `${dd} ${TR_MONTHS[(mm ?? 1) - 1]}`;
}

function offsetDate(base: string, days: number): string {
  const d = new Date(base + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/** HH:MM in Istanbul timezone */
export function formatTime(iso: string): string {
  try {
    return new Date(iso).toLocaleTimeString('tr-TR', {
      hour: '2-digit', minute: '2-digit',
      timeZone: TZ, hour12: false,
    });
  } catch { return ''; }
}

/** DD MMM in Turkish */
export function formatShortDate(iso: string): string {
  try {
    const d = new Date(iso);
    const day = new Intl.DateTimeFormat('tr-TR', { timeZone: TZ, day: 'numeric' }).format(d);
    const month = new Intl.DateTimeFormat('tr-TR', { timeZone: TZ, month: 'short' }).format(d);
    return `${day} ${month}`;
  } catch { return ''; }
}
