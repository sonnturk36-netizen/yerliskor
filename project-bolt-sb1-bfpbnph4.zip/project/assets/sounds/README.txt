# Goal sound placeholder files

Place the following audio files here:
- `kick.mp3` — Football kick sound
- `net.mp3` — Net sound
- `cheer.mp3` — Crowd cheer
- `gool.mp3` — Voice saying "GOOOL!"
- `goal_combined.mp3` — Combined goal sound (current placeholder)
