import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class TeamLogo extends StatelessWidget {
  final String? logoUrl;
  final String fallbackText;
  final double size;

  const TeamLogo({
    super.key,
    this.logoUrl,
    required this.fallbackText,
    this.size = 48,
  });

  @override
  Widget build(BuildContext context) {
    final initials = fallbackText.isNotEmpty
        ? fallbackText.substring(0, fallbackText.length > 3 ? 3 : fallbackText.length).toUpperCase()
        : '?';

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(size * 0.25),
        border: Border.all(color: AppColors.divider, width: 1),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size * 0.25),
        child: (logoUrl != null && logoUrl!.isNotEmpty)
            ? Image.network(
                logoUrl!,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => _fallback(initials),
              )
            : _fallback(initials),
      ),
    );
  }

  Widget _fallback(String initials) {
    return Center(
      child: Text(
        initials,
        style: TextStyle(
          fontSize: size * 0.30,
          fontWeight: FontWeight.w700,
          color: AppColors.primary,
        ),
      ),
    );
  }
}
