import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class BrandLogo extends StatelessWidget {
  final double size;
  final bool withText;

  const BrandLogo({
    super.key,
    this.size = 36,
    this.withText = true,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(size * 0.28),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withValues(alpha: 0.30),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Center(
            child: Icon(
              Icons.sports_soccer,
              color: Colors.white,
              size: size * 0.55,
            ),
          ),
        ),
        if (withText) ...[
          const SizedBox(width: 10),
          RichText(
            text: const TextSpan(
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w700,
                fontFamily: 'Poppins',
              ),
              children: [
                TextSpan(
                  text: 'Yerli',
                  style: TextStyle(color: AppColors.text),
                ),
                TextSpan(
                  text: 'Skor',
                  style: TextStyle(color: AppColors.primary),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}
