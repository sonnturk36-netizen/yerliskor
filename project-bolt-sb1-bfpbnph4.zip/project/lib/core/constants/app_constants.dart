class AppConstants {
  AppConstants._();

  static const String appName = 'YerliSkor';
  static const Duration splashDuration = Duration(seconds: 2);
  static const String notificationPermissionRequestedKey =
      'notification_permission_requested';
  static const String notificationsStorageKey = 'stored_notifications';

  static const String goalSoundKick = 'kick.mp3';
  static const String goalSoundNet = 'net.mp3';
  static const String goalSoundCheer = 'cheer.mp3';
  static const String goalSoundVoice = 'gool.mp3';
}
