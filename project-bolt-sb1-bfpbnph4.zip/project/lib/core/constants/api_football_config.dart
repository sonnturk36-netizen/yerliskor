/// API-Football configuration.
///
/// League IDs for Turkish football competitions:
///   203 — Trendyol Süper Lig
///   204 — Trendyol 1. Lig
///   205 — TFF 2. Lig
///   206 — TFF 3. Lig
///   207 — Ziraat Türkiye Kupası
library;

import 'package:flutter_dotenv/flutter_dotenv.dart';

class ApiFootballConfig {
  ApiFootballConfig._();

  static const String baseUrl = 'https://v3.football.api-sports.io';

  /// Turkish league IDs to fetch fixtures from.
  static const List<int> turkishLeagueIds = [203, 204, 205, 206, 207];

  /// League ID → display name.
  static const Map<int, String> leagueNames = {
    203: 'Trendyol Süper Lig',
    204: 'Trendyol 1. Lig',
    205: 'TFF 2. Lig',
    206: 'TFF 3. Lig',
    207: 'Ziraat Türkiye Kupası',
  };

  /// Default season year (auto-updated in runtime).
  static int get currentSeason => DateTime.now().month >= 7
      ? DateTime.now().year
      : DateTime.now().year - 1;

  /// Timezone for fixture dates.
  static const String timezone = 'Europe/Istanbul';

  /// Polling interval for live match updates.
  static const Duration pollInterval = Duration(seconds: 30);

  /// HTTP request timeout.
  static const Duration requestTimeout = Duration(seconds: 15);

  /// Maximum retry attempts for failed requests.
  static const int maxRetries = 3;

  /// Cache TTL for match list.
  static const Duration cacheTtl = Duration(minutes: 5);

  /// Reads the API key from the environment.
  /// Supports both --dart-define and flutter_dotenv (.env file).
  static String get apiKey {
    // Try compile-time --dart-define first
    const key = String.fromEnvironment(
      'API_FOOTBALL_KEY',
      defaultValue: '',
    );
    if (key.isNotEmpty && key != 'YOUR_API_KEY_HERE') return key;

    // Try flutter_dotenv at runtime
    try {
      final envKey = dotenv.maybeGet('API_FOOTBALL_KEY') ?? '';
      if (envKey.isNotEmpty && envKey != 'YOUR_API_KEY_HERE') return envKey;
    } catch (_) {}

    return '';
  }

  static bool get isApiKeyConfigured =>
      apiKey.isNotEmpty && apiKey != 'YOUR_API_KEY_HERE';
}
