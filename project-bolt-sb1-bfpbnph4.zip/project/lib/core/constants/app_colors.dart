import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color background = Color(0xFFF8F8F6);
  static const Color card = Colors.white;
  static const Color primary = Color(0xFFD50000);
  static const Color primaryDark = Color(0xFFB71C1C);
  static const Color text = Color(0xFF222222);
  static const Color textSecondary = Color(0xFF6B6B6B);
  static const Color textTertiary = Color(0xFF9E9E9E);
  static const Color divider = Color(0xFFE0E0E0);
  static const Color redDivider = Color(0xFFD50000);

  static const Color success = Color(0xFF2E7D32);
  static const Color warning = Color(0xFFF9A825);
  static const Color error = Color(0xFFC62828);

  static const Color liveRed = Color(0xFFD50000);
  static const Color yellowCard = Color(0xFFFBC02D);
  static const Color redCard = Color(0xFFD50000);
}
