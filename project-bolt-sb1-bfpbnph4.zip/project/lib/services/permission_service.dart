import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants/app_constants.dart';

class PermissionService {
  static final PermissionService _instance = PermissionService._internal();
  factory PermissionService() => _instance;
  PermissionService._internal();

  Future<bool> shouldRequestNotificationPermission() async {
    final prefs = await SharedPreferences.getInstance();
    return !prefs.getBool(AppConstants.notificationPermissionRequestedKey) ??
        true;
  }

  Future<bool> requestNotificationPermission() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(AppConstants.notificationPermissionRequestedKey, true);

    if (await Permission.notification.isGranted) {
      return true;
    }

    final result = await Permission.notification.request();
    return result.isGranted;
  }
}
