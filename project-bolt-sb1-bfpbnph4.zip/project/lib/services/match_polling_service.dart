import 'dart:async';
import 'package:flutter/foundation.dart';
import '../core/constants/api_football_config.dart';
import '../data/repositories/football_repository_impl.dart';
import '../domain/entities/match.dart';
import 'notification_service.dart';

/// Polls live Turkish football matches at a fixed interval.
///
/// Compares each poll result with the previous snapshot and fires
/// [NotificationService] push notifications when:
///   - A match starts (NS → 1H/2H/LIVE)
///   - Half time is reached (1H → HT)
///   - Second half starts (HT → 2H)
///   - Full time is reached (→ FT)
///   - A new goal is scored
///   - A new red card is shown
class MatchPollingService extends ChangeNotifier {
  MatchPollingService({
    required FootballRepositoryImpl repository,
    required NotificationService notificationService,
  })  : _repository = repository,
        _notifications = notificationService;

  final FootballRepositoryImpl _repository;
  final NotificationService _notifications;

  Timer? _timer;
  bool _isPolling = false;
  bool _isRunning = false;

  List<Match> _matches = [];
  List<Match> get matches => List.unmodifiable(_matches);

  /// Previous snapshot keyed by match ID for diffing.
  final Map<String, Match> _previousSnapshot = {};

  bool get isRunning => _isRunning;

  /// Starts polling. Fetches immediately, then at [ApiFootballConfig.pollInterval].
  void start() {
    if (_isRunning) return;
    _isRunning = true;
    _poll();
    _timer = Timer.periodic(ApiFootballConfig.pollInterval, (_) => _poll());
  }

  /// Stops polling.
  void stop() {
    _isRunning = false;
    _timer?.cancel();
    _timer = null;
  }

  /// Forces an immediate poll.
  Future<void> pollNow() async {
    await _poll();
  }

  Future<void> _poll() async {
    if (_isPolling) return;
    _isPolling = true;

    try {
      final liveMatches = await _repository.getLiveMatches();
      final allMatches = await _repository.getMatches(forceRefresh: true);

      // Merge: live matches (with fresh data) + other matches
      final liveIds = liveMatches.map((m) => m.id).toSet();
      final others = allMatches.where((m) => !liveIds.contains(m.id)).toList();
      _matches = [...liveMatches, ...others];

      // Detect changes and fire notifications
      _detectChanges(liveMatches);

      // Update snapshot
      _previousSnapshot.clear();
      for (final m in liveMatches) {
        _previousSnapshot[m.id] = m;
      }

      notifyListeners();
    } catch (_) {
      // Silent failure — keep previous data, retry next cycle
    } finally {
      _isPolling = false;
    }
  }

  void _detectChanges(List<Match> current) {
    for (final match in current) {
      final previous = _previousSnapshot[match.id];

      // New match appeared in live — match started
      if (previous == null) {
        if (match.status == MatchStatus.live) {
          _sendMatchStarted(match);
        }
        continue;
      }

      // Status transitions
      if (previous.status != match.status) {
        // Half time
        if (previous.status == MatchStatus.live &&
            match.status == MatchStatus.halftime) {
          _sendHalfTime(match);
        }
        // Second half started
        else if (previous.status == MatchStatus.halftime &&
            match.status == MatchStatus.live) {
          _sendSecondHalfStarted(match);
        }
        // Full time
        else if ((previous.status == MatchStatus.live ||
                previous.status == MatchStatus.halftime) &&
            match.status == MatchStatus.finished) {
          _sendFullTime(match);
        }
      }

      // Score change → goal
      if (match.homeScore > previous.homeScore) {
        _sendGoalNotification(match, isHome: true);
      }
      if (match.awayScore > previous.awayScore) {
        _sendGoalNotification(match, isHome: false);
      }

      // New events (cards) — compare event counts
      _detectNewCards(match, previous);
    }
  }

  void _detectNewCards(Match match, Match previous) {
    final prevEventIds = previous.events.map((e) => e.id).toSet();
    for (final event in match.events) {
      if (prevEventIds.contains(event.id)) continue;

      if (event.type == EventType.redCard) {
        _sendRedCardNotification(match, event);
      } else if (event.type == EventType.yellowCard) {
        _sendYellowCardNotification(match, event);
      }
    }
  }

  void _sendGoalNotification(Match match, {required bool isHome}) {
    final scorer = _findLatestScorer(match, isHome);
    final scoringTeam = isHome ? match.homeTeam.name : match.awayTeam.name;

    _notifications.showNotification(
      type: NotificationType.goal,
      title: '⚽ GOOOL!',
      body: '$scoringTeam ${match.homeScore}-${match.awayScore} ${match.awayTeam.name}\n$scorer ${match.minute}',
      matchId: match.id,
    );
  }

  String _findLatestScorer(Match match, bool isHome) {
    final teamId = isHome ? match.homeTeam.id : match.awayTeam.id;
    final goals = match.events
        .where((e) =>
            e.type == EventType.goal && e.teamId == teamId)
        .toList();
    if (goals.isNotEmpty) {
      return goals.last.playerName;
    }
    return '';
  }

  void _sendMatchStarted(Match match) {
    _notifications.showNotification(
      type: NotificationType.matchStarted,
      title: '🔴 Maç Başladı',
      body: '${match.homeTeam.name} - ${match.awayTeam.name}',
      matchId: match.id,
    );
  }

  void _sendHalfTime(Match match) {
    _notifications.showNotification(
      type: NotificationType.halfTime,
      title: '⏸ Devre Arası',
      body: '${match.homeTeam.name} ${match.homeScore}-${match.awayScore} ${match.awayTeam.name}',
      matchId: match.id,
    );
  }

  void _sendSecondHalfStarted(Match match) {
    _notifications.showNotification(
      type: NotificationType.secondHalfStarted,
      title: '▶ İkinci Yarı Başladı',
      body: '${match.homeTeam.name} ${match.homeScore}-${match.awayScore} ${match.awayTeam.name}',
      matchId: match.id,
    );
  }

  void _sendFullTime(Match match) {
    _notifications.showNotification(
      type: NotificationType.fullTime,
      title: '🏁 Maç Bitti',
      body: '${match.homeTeam.name} ${match.homeScore}-${match.awayScore} ${match.awayTeam.name}',
      matchId: match.id,
    );
  }

  void _sendRedCardNotification(Match match, MatchEvent event) {
    final team = event.teamId == match.homeTeam.id
        ? match.homeTeam.name
        : match.awayTeam.name;
    _notifications.showNotification(
      type: NotificationType.redCard,
      title: '🟥 Kırmızı Kart!',
      body: '$team - ${event.playerName} ${event.minute}',
      matchId: match.id,
    );
  }

  void _sendYellowCardNotification(Match match, MatchEvent event) {
    final team = event.teamId == match.homeTeam.id
        ? match.homeTeam.name
        : match.awayTeam.name;
    _notifications.showNotification(
      type: NotificationType.yellowCard,
      title: '🟨 Sarı Kart',
      body: '$team - ${event.playerName} ${event.minute}',
      matchId: match.id,
    );
  }

  @override
  void dispose() {
    stop();
    super.dispose();
  }
}
