import 'package:audioplayers/audioplayers.dart';
import '../core/constants/app_constants.dart';

class GoalSoundService {
  static final GoalSoundService _instance = GoalSoundService._internal();
  factory GoalSoundService() => _instance;
  GoalSoundService._internal();

  final AudioPlayer _player = AudioPlayer();

  /// Plays the custom goal sound sequence:
  /// 1. Football kick
  /// 2. Net sound
  /// 3. Crowd cheer
  /// 4. Voice saying "GOOOL!"
  ///
  /// For now this plays a single combined placeholder.
  /// When individual sound files are available in assets/sounds/,
  /// this method will play them in sequence.
  Future<void> playGoalSound() async {
    try {
      await _player.setReleaseMode(ReleaseMode.stop);
      await _player.setVolume(1.0);

      // Play the combined goal sound (placeholder).
      // Replace with sequential playback when individual files exist:
      //
      // await _player.play(AssetSource('sounds/${AppConstants.goalSoundKick}'));
      // await Future.delayed(const Duration(milliseconds: 200));
      // await _player.play(AssetSource('sounds/${AppConstants.goalSoundNet}'));
      // await Future.delayed(const Duration(milliseconds: 300));
      // await _player.play(AssetSource('sounds/${AppConstants.goalSoundCheer}'));
      // await Future.delayed(const Duration(milliseconds: 500));
      // await _player.play(AssetSource('sounds/${AppConstants.goalSoundVoice}'));

      await _player.play(AssetSource('sounds/goal_combined.mp3'));
    } catch (_) {
      // Sound files not yet available — silent fallback.
    }
  }

  Future<void> dispose() async {
    await _player.dispose();
  }
}
