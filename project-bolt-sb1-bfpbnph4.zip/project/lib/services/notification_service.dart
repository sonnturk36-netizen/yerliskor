import 'dart:convert';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants/app_constants.dart';
import '../domain/entities/app_notification.dart';

class NotificationService extends ChangeNotifier {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  final List<AppNotification> _history = [];
  List<AppNotification> get history => List.unmodifiable(_history);

  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );
    const initSettings = InitializationSettings(
      android: androidInit,
      iOS: iosInit,
    );

    await _plugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    await _loadHistory();
  }

  void Function(AppNotification)? onNotificationReceived;
  void Function(AppNotification)? onNotificationTapped;

  Future<bool> requestPermission() async {
    final android = _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    if (android != null) {
      final granted = await android.requestNotificationsPermission();
      return granted ?? false;
    }
    final ios = _plugin
        .resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin>();
    if (ios != null) {
      final granted = await ios.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );
      return granted ?? false;
    }
    return false;
  }

  Future<void> showNotification({
    required NotificationType type,
    required String title,
    required String body,
    String? matchId,
  }) async {
    final notification = AppNotification(
      id: '${DateTime.now().millisecondsSinceEpoch}',
      type: type,
      title: title,
      body: body,
      matchId: matchId,
      timestamp: DateTime.now(),
    );

    _addToHistory(notification);
    notifyListeners();

    const androidDetails = AndroidNotificationDetails(
      'yerliskor_channel',
      'YerliSkor Bildirimleri',
      channelDescription: 'Gol, kart ve maç durum bildirimleri',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
      enableVibration: true,
    );
    const iosDetails = DarwinNotificationDetails();
    const details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _plugin.show(
      notification.id.hashCode,
      title,
      body,
      details,
      payload: notification.id,
    );

    onNotificationReceived?.call(notification);
  }

  void _onNotificationTapped(NotificationResponse response) {
    final id = response.payload;
    if (id != null) {
      final notif = _history.where((n) => n.id == id).firstOrNull;
      if (notif != null) {
        onNotificationTapped?.call(notif);
      }
    }
  }

  void _addToHistory(AppNotification notification) {
    _history.insert(0, notification);
    _saveHistory();
  }

  void markAsRead(String id) {
    final index = _history.indexWhere((n) => n.id == id);
    if (index != -1) {
      _history[index] = _history[index].copyWith(read: true);
      _saveHistory();
      notifyListeners();
    }
  }

  void markAllAsRead() {
    for (var i = 0; i < _history.length; i++) {
      _history[i] = _history[i].copyWith(read: true);
    }
    _saveHistory();
    notifyListeners();
  }

  void clearHistory() {
    _history.clear();
    _saveHistory();
    notifyListeners();
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = _history.map((n) => n.toJson()).toList();
    await prefs.setString(
      AppConstants.notificationsStorageKey,
      jsonEncode(jsonList),
    );
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString(AppConstants.notificationsStorageKey);
    if (stored != null && stored.isNotEmpty) {
      final jsonList = jsonDecode(stored) as List;
      _history.clear();
      _history.addAll(
        jsonList
            .map((e) => AppNotification.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
      _history.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    }
  }

  int get unreadCount => _history.where((n) => !n.read).length;
}
