import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../domain/entities/match.dart';

class EventTimeline extends StatelessWidget {
  final Match match;
  const EventTimeline({super.key, required this.match});

  @override
  Widget build(BuildContext context) {
    final events = List<MatchEvent>.from(match.events)
      ..sort((a, b) => a.minute.compareTo(b.minute));

    if (events.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Center(
          child: Text(
            'Henüz olay yok',
            style: TextStyle(color: AppColors.textTertiary),
          ),
        ),
      );
    }

    return Column(
      children: events.map((event) => _EventTile(event: event, match: match)).toList(),
    );
  }
}

class _EventTile extends StatelessWidget {
  final MatchEvent event;
  final Match match;

  const _EventTile({required this.event, required this.match});

  @override
  Widget build(BuildContext context) {
    final isHome = event.teamId == match.homeTeam.id;
    final team = isHome ? match.homeTeam : match.awayTeam;

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 44,
            child: Text(
              "${event.minute}'",
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: AppColors.primary,
              ),
            ),
          ),
          Container(
            width: 1,
            color: AppColors.divider,
            margin: const EdgeInsets.only(top: 2, bottom: 2),
          ),
          Expanded(
            child: _eventContent(isHome, team.shortName),
          ),
        ],
      ),
    );
  }

  Widget _eventContent(bool isHome, String teamShort) {
    final icon = _eventIcon();
    final iconColor = _eventIconColor();
    final description = _eventDescription();

    return Padding(
      padding: const EdgeInsets.only(left: 12, bottom: 16, top: 2),
      child: Row(
        textDirection: isHome ? TextDirection.ltr : TextDirection.rtl,
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 16, color: iconColor),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: isHome
                  ? CrossAxisAlignment.start
                  : CrossAxisAlignment.end,
              children: [
                Text(
                  description,
                  textAlign: isHome ? TextAlign.start : TextAlign.end,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppColors.text,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  teamShort,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textTertiary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  IconData _eventIcon() {
    return switch (event.type) {
      EventType.goal => Icons.sports_soccer,
      EventType.yellowCard => Icons.square,
      EventType.redCard => Icons.square,
      EventType.substitution => Icons.swap_horiz,
      EventType.varDecision => Icons.tv,
    };
  }

  Color _eventIconColor() {
    return switch (event.type) {
      EventType.goal => AppColors.primary,
      EventType.yellowCard => AppColors.yellowCard,
      EventType.redCard => AppColors.redCard,
      EventType.substitution => AppColors.textSecondary,
      EventType.varDecision => AppColors.textSecondary,
    };
  }

  String _eventDescription() {
    return switch (event.type) {
      EventType.goal => 'GOL · ${event.playerName}',
      EventType.yellowCard => 'Sarı Kart · ${event.playerName}',
      EventType.redCard => 'Kırmızı Kart · ${event.playerName}',
      EventType.substitution =>
        '${event.playerName} ➜ ${event.replacedByPlayerName ?? ''}',
      EventType.varDecision => 'VAR · ${event.playerName}',
    };
  }
}
