import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../domain/entities/match.dart';

class MatchInfoBar extends StatelessWidget {
  final Match match;
  const MatchInfoBar({super.key, required this.match});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _infoItem(Icons.stadium, match.stadium ?? 'Stadyum'),
          _divider(),
          _infoItem(Icons.whistle, match.referee ?? 'Hakem'),
          _divider(),
          _infoItem(Icons.timer, _statusText()),
        ],
      ),
    );
  }

  Widget _infoItem(IconData icon, String label) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, size: 18, color: AppColors.primary),
          const SizedBox(height: 4),
          Text(
            label,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _divider() {
    return Container(width: 1, height: 32, color: AppColors.divider);
  }

  String _statusText() {
    return switch (match.status) {
      MatchStatus.live => "Canlı ${match.minute}'",
      MatchStatus.halftime => 'Devre Arası',
      MatchStatus.finished => 'Bitti',
      MatchStatus.scheduled => 'Bekliyor',
      MatchStatus.postponed => 'Ertelendi',
    };
  }
}
