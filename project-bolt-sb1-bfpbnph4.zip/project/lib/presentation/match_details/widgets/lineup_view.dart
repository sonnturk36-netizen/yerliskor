import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../domain/entities/match.dart';

class LineupView extends StatelessWidget {
  final Match match;
  final bool isBench;
  const LineupView({super.key, required this.match, this.isBench = false});

  @override
  Widget build(BuildContext context) {
    final homePlayers = isBench ? match.homeBench : match.homeStartingXI;
    final awayPlayers = isBench ? match.awayBench : match.awayStartingXI;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(child: _teamColumn(match.homeTeam.name, homePlayers)),
        Container(width: 1, color: AppColors.divider),
        Expanded(child: _teamColumn(match.awayTeam.name, awayPlayers)),
      ],
    );
  }

  Widget _teamColumn(String teamName, List<Player> players) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Text(
            teamName,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: AppColors.primary,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          ...players.map((p) => _playerRow(p)),
        ],
      ),
    );
  }

  Widget _playerRow(Player p) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Center(
              child: Text(
                '${p.number}',
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: AppColors.primary,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  p.name,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: AppColors.text,
                  ),
                ),
                Text(
                  p.position,
                  style: const TextStyle(
                    fontSize: 10,
                    color: AppColors.textTertiary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
