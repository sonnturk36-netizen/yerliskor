import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/widgets/app_card.dart';
import '../../../core/widgets/section_header.dart';
import '../../../domain/entities/match.dart';
import '../../../domain/usecases/get_match_by_id.dart';
import '../widgets/event_timeline.dart';
import '../widgets/lineup_view.dart';
import '../widgets/match_info_bar.dart';
import '../widgets/match_score_header.dart';

class MatchDetailsScreen extends StatefulWidget {
  final Match match;
  const MatchDetailsScreen({super.key, required this.match});

  @override
  State<MatchDetailsScreen> createState() => _MatchDetailsScreenState();
}

class _MatchDetailsScreenState extends State<MatchDetailsScreen> {
  late Future<Match?> _matchFuture;

  @override
  void initState() {
    super.initState();
    _loadMatchDetails();
  }

  void _loadMatchDetails() {
    final usecase = context.read<GetMatchById>();
    _matchFuture = usecase(widget.match.id, forceRefresh: true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Maç Detayı'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.text),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: FutureBuilder<Match?>(
        future: _matchFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return _buildLoading(widget.match);
          }

          if (snapshot.hasError) {
            return _buildError();
          }

          final match = snapshot.data ?? widget.match;

          return _buildContent(match);
        },
      ),
    );
  }

  Widget _buildContent(Match match) {
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      children: [
        const SizedBox(height: 12),
        MatchScoreHeader(match: match),
        const SizedBox(height: 12),
        MatchInfoBar(match: match),
        const SectionHeader(title: 'Olaylar', icon: Icons.timeline),
        AppCard(
          padding: const EdgeInsets.all(16),
          child: EventTimeline(match: match),
        ),
        const SectionHeader(title: 'İlk 11', icon: Icons.group),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: LineupView(match: match),
        ),
        const SectionHeader(title: 'Yedekler', icon: Icons.chair),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: LineupView(match: match, isBench: true),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildLoading(Match match) {
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      children: [
        const SizedBox(height: 12),
        MatchScoreHeader(match: match),
        const SizedBox(height: 12),
        MatchInfoBar(match: match),
        const SizedBox(height: 40),
        const Center(
          child: CircularProgressIndicator(color: AppColors.primary),
        ),
        const SizedBox(height: 16),
        const Center(
          child: Text(
            'Olaylar ve kadrolar yükleniyor...',
            style: TextStyle(color: AppColors.textSecondary),
          ),
        ),
      ],
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.wifi_off, size: 48, color: AppColors.textTertiary),
          const SizedBox(height: 12),
          const Text(
            'Maç detayları yüklenemedi',
            style: TextStyle(color: AppColors.textSecondary),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: () {
              setState(() => _loadMatchDetails());
            },
            icon: const Icon(Icons.refresh, size: 18),
            label: const Text('Tekrar Dene'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
