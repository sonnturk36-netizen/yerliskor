import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';

class LiveBanner extends StatelessWidget {
  final int liveCount;
  const LiveBanner({super.key, required this.liveCount});

  @override
  Widget build(BuildContext context) {
    final hasLive = liveCount > 0;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: hasLive
            ? AppColors.primary.withValues(alpha: 0.08)
            : AppColors.background,
        border: const Border(
          bottom: BorderSide(color: AppColors.redDivider, width: 0.5),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (hasLive) ...[
            const _LiveDot(),
            const SizedBox(width: 6),
          ] else ...[
            const Icon(Icons.circle_outlined, size: 8, color: AppColors.textTertiary),
            const SizedBox(width: 6),
          ],
          Text(
            hasLive ? 'CANLI • $liveCount MAÇ' : 'ŞU AN CANLI MAÇ YOK',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.8,
              color: hasLive ? AppColors.primary : AppColors.textTertiary,
            ),
          ),
        ],
      ),
    );
  }
}

class _LiveDot extends StatefulWidget {
  const _LiveDot();

  @override
  State<_LiveDot> createState() => _LiveDotState();
}

class _LiveDotState extends State<_LiveDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _controller,
      child: Container(
        width: 8,
        height: 8,
        decoration: const BoxDecoration(
          color: AppColors.primary,
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}
