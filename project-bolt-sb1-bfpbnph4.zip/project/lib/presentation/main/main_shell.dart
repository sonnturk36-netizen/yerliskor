import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';
import '../../core/widgets/brand_logo.dart';
import '../../domain/entities/match.dart';
import '../../services/match_polling_service.dart';
import '../../services/notification_service.dart';
import '../match_details/screens/match_details_screen.dart';
import '../matches/screens/matches_screen.dart';
import '../notifications/screens/notifications_screen.dart';
import 'live_banner.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 0;

  void _openMatchDetails(Match match) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => MatchDetailsScreen(match: match),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final notifService = context.watch<NotificationService>();
    final pollingService = context.watch<MatchPollingService>();
    final unreadCount = notifService.unreadCount;
    final liveCount = pollingService.matches.where((m) => m.isLive).length;

    return Scaffold(
      appBar: _MainAppBar(liveCount: liveCount),
      body: IndexedStack(
        index: _currentIndex,
        children: [
          MatchesScreen(onMatchTapped: _openMatchDetails),
          const NotificationsScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (i) => setState(() => _currentIndex = i),
        destinations: [
          const NavigationDestination(
            icon: Icon(Icons.sports_soccer_outlined),
            selectedIcon: Icon(Icons.sports_soccer),
            label: 'Maçlar',
          ),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: unreadCount > 0,
              label: Text('$unreadCount'),
              child: const Icon(Icons.notifications_outlined),
            ),
            selectedIcon: Badge(
              isLabelVisible: unreadCount > 0,
              label: Text('$unreadCount'),
              child: const Icon(Icons.notifications),
            ),
            label: 'Bildirimler',
          ),
        ],
      ),
    );
  }
}

class _MainAppBar extends StatelessWidget implements PreferredSizeWidget {
  final int liveCount;
  const _MainAppBar({required this.liveCount});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          color: AppColors.card,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: const BrandLogo(size: 36),
        ),
        LiveBanner(liveCount: liveCount),
      ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(80);
}
