import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/api_football_config.dart';
import '../../../core/widgets/section_header.dart';
import '../../../domain/entities/match.dart';
import '../../../domain/usecases/get_matches.dart';
import '../../../services/match_polling_service.dart';
import '../widgets/match_card.dart';

class MatchesScreen extends StatefulWidget {
  final void Function(Match match) onMatchTapped;
  const MatchesScreen({super.key, required this.onMatchTapped});

  @override
  State<MatchesScreen> createState() => _MatchesScreenState();
}

class _MatchesScreenState extends State<MatchesScreen>
    with AutomaticKeepAliveClientMixin {
  late Future<List<Match>> _matchesFuture;
  bool _isRetrying = false;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadMatches();
  }

  void _loadMatches() {
    final usecase = context.read<GetMatches>();
    _matchesFuture = usecase.call(forceRefresh: true);
  }

  Future<void> _refresh() async {
    setState(() {
      _isRetrying = true;
      _loadMatches();
    });
    try {
      await _matchesFuture;
    } catch (_) {}
    if (mounted) setState(() => _isRetrying = false);
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    // Listen to polling service for auto-updates
    context.watch<MatchPollingService>();

    return Scaffold(
      body: RefreshIndicator(
        color: AppColors.primary,
        onRefresh: _refresh,
        child: FutureBuilder<List<Match>>(
          future: _matchesFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting &&
                !snapshot.hasData) {
              return _loadingView();
            }
            if (snapshot.hasError && !snapshot.hasData) {
              return _errorView(snapshot.error);
            }

            // Use polling service data if available, otherwise future data
            final pollingService = context.read<MatchPollingService>();
            var matches = pollingService.matches.isNotEmpty
                ? pollingService.matches
                : (snapshot.data ?? []);

            // Merge: if polling has live matches, supplement with future data
            if (pollingService.matches.isNotEmpty && snapshot.hasData) {
              final liveIds =
                  pollingService.matches.map((m) => m.id).toSet();
              final others =
                  snapshot.data!.where((m) => !liveIds.contains(m.id));
              matches = [...pollingService.matches, ...others];
            }

            matches = _sortMatches(matches);

            if (matches.isEmpty) {
              return _emptyView();
            }

            final liveMatches = matches.where((m) => m.isLive).toList();
            final otherMatches = matches.where((m) => !m.isLive).toList();

            return ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                if (liveMatches.isNotEmpty) ...[
                  const SectionHeader(
                    title: 'Canlı Maçlar',
                    icon: Icons.sports_soccer,
                  ),
                  ...liveMatches.map(
                    (m) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: MatchCard(
                        match: m,
                        onTap: () => widget.onMatchTapped(m),
                      ),
                    ),
                  ),
                ],
                if (otherMatches.isNotEmpty) ...[
                  const SectionHeader(
                    title: 'Diğer Maçlar',
                    icon: Icons.history,
                    accentColor: AppColors.textTertiary,
                  ),
                  ...otherMatches.map(
                    (m) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: MatchCard(
                        match: m,
                        onTap: () => widget.onMatchTapped(m),
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 24),
              ],
            );
          },
        ),
      ),
    );
  }

  List<Match> _sortMatches(List<Match> matches) {
    final sorted = List<Match>.from(matches);
    sorted.sort((a, b) {
      if (a.isLive && !b.isLive) return -1;
      if (!a.isLive && b.isLive) return 1;
      if (a.isLive && b.isLive) return b.minute.compareTo(a.minute);
      return (a.kickoffTime ?? DateTime.now())
          .compareTo(b.kickoffTime ?? DateTime.now());
    });
    return sorted;
  }

  Widget _loadingView() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircularProgressIndicator(color: AppColors.primary),
          const SizedBox(height: 16),
          Text(
            _isRetrying ? 'Tekrar yükleniyor...' : 'Maçlar yükleniyor...',
            style: const TextStyle(color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }

  Widget _errorView(Object? error) {
    final isApiKeyMissing = !ApiFootballConfig.isApiKeyConfigured;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isApiKeyMissing ? Icons.key_off : Icons.wifi_off,
              size: 48,
              color: AppColors.textTertiary,
            ),
            const SizedBox(height: 12),
            Text(
              isApiKeyMissing
                  ? 'API anahtarı gerekli'
                  : 'Maçlar yüklenemedi',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              isApiKeyMissing
                  ? 'Lütfen .env dosyasına API_FOOTBALL_KEY ekleyin'
                  : 'İnternet bağlantınızı kontrol edin',
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textTertiary),
            ),
            const SizedBox(height: 16),
            if (!isApiKeyMissing)
              ElevatedButton.icon(
                onPressed: _refresh,
                icon: const Icon(Icons.refresh, size: 18),
                label: const Text('Tekrar Dene'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  foregroundColor: Colors.white,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _emptyView() {
    return ListView(
      padding: const EdgeInsets.all(32),
      children: const [
        SizedBox(height: 80),
        Icon(Icons.sports_soccer, size: 64, color: AppColors.textTertiary),
        SizedBox(height: 16),
        Center(
          child: Text(
            'Şu anda canlı maç yok',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppColors.textSecondary,
            ),
          ),
        ),
        SizedBox(height: 8),
        Center(
          child: Text(
            'Maçlar başladığında burada görünecek',
            style: TextStyle(color: AppColors.textTertiary),
          ),
        ),
      ],
    );
  }
}
