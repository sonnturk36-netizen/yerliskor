import '../../domain/entities/match.dart';

/// DTO for API-Football /fixtures response items.
/// Maps raw JSON to domain [Match] entities.
class FixtureDto {
  final int id;
  final String? referee;
  final String? venueName;
  final String? venueCity;
  final String statusShort;
  final String statusLong;
  final int? elapsed;
  final DateTime? date;
  final int leagueId;
  final String leagueName;
  final String? leagueLogo;
  final String? round;
  final Team homeTeam;
  final Team awayTeam;
  final int? homeGoals;
  final int? awayGoals;
  final int? halftimeHome;
  final int? halftimeAway;
  final int? fulltimeHome;
  final int? fulltimeAway;

  FixtureDto({
    required this.id,
    this.referee,
    this.venueName,
    this.venueCity,
    required this.statusShort,
    required this.statusLong,
    this.elapsed,
    this.date,
    required this.leagueId,
    required this.leagueName,
    this.leagueLogo,
    this.round,
    required this.homeTeam,
    required this.awayTeam,
    this.homeGoals,
    this.awayGoals,
    this.halftimeHome,
    this.halftimeAway,
    this.fulltimeHome,
    this.fulltimeAway,
  });

  factory FixtureDto.fromJson(Map<String, dynamic> json) {
    final fixture = json['fixture'] as Map<String, dynamic>;
    final league = json['league'] as Map<String, dynamic>;
    final teams = json['teams'] as Map<String, dynamic>;
    final goals = json['goals'] as Map<String, dynamic>;
    final score = json['score'] as Map<String, dynamic>;
    final venue = fixture['venue'] as Map<String, dynamic>?;
    final status = fixture['status'] as Map<String, dynamic>;

    final home = teams['home'] as Map<String, dynamic>;
    final away = teams['away'] as Map<String, dynamic>;
    final halftime = score['halftime'] as Map<String, dynamic>?;
    final fulltime = score['fulltime'] as Map<String, dynamic>?;

    return FixtureDto(
      id: fixture['id'] as int,
      referee: fixture['referee'] as String?,
      venueName: venue?['name'] as String?,
      venueCity: venue?['city'] as String?,
      statusShort: status['short'] as String,
      statusLong: status['long'] as String,
      elapsed: status['elapsed'] as int?,
      date: fixture['timestamp'] != null
          ? DateTime.fromMillisecondsSinceEpoch(
              (fixture['timestamp'] as int) * 1000,
            )
          : null,
      leagueId: league['id'] as int,
      leagueName: league['name'] as String,
      leagueLogo: league['logo'] as String?,
      round: league['round'] as String?,
      homeTeam: Team(
        id: '${home['id']}',
        name: home['name'] as String,
        shortName: _shortName(home['name'] as String),
        logoUrl: home['logo'] as String?,
      ),
      awayTeam: Team(
        id: '${away['id']}',
        name: away['name'] as String,
        shortName: _shortName(away['name'] as String),
        logoUrl: away['logo'] as String?,
      ),
      homeGoals: goals['home'] as int?,
      awayGoals: goals['away'] as int?,
      halftimeHome: halftime?['home'] as int?,
      halftimeAway: halftime?['away'] as int?,
      fulltimeHome: fulltime?['home'] as int?,
      fulltimeAway: fulltime?['away'] as int?,
    );
  }

  Match toDomain() {
    return Match(
      id: '$id',
      homeTeam: homeTeam,
      awayTeam: awayTeam,
      homeScore: homeGoals ?? 0,
      awayScore: awayGoals ?? 0,
      status: _mapStatus(statusShort),
      minute: elapsed ?? 0,
      referee: referee,
      stadium: _stadiumString(),
      competition: leagueName,
      kickoffTime: date,
    );
  }

  String? _stadiumString() {
    if (venueName != null && venueCity != null) {
      return '$venueName, $venueCity';
    }
    return venueName;
  }

  static MatchStatus _mapStatus(String short) {
    return switch (short) {
      '1H' || '2H' || 'LIVE' || 'ET' || 'P' || 'BT' => MatchStatus.live,
      'HT' => MatchStatus.halftime,
      'FT' || 'AET' || 'PEN' || 'AWD' || 'WO' => MatchStatus.finished,
      'PST' || 'CANC' || 'ABD' || 'SUSP' || 'INT' => MatchStatus.postponed,
      _ => MatchStatus.scheduled,
    };
  }

  static String _shortName(String name) {
    if (name.length <= 3) return name.toUpperCase();
    final words = name.split(' ');
    if (words.length >= 2) {
      return words.take(3).map((w) => w[0].toUpperCase()).join();
    }
    return name.substring(0, 3).toUpperCase();
  }
}

/// DTO for API-Football /fixtures/events response items.
class EventDto {
  final int minute;
  final int? extraTime;
  final int teamId;
  final String teamName;
  final String playerName;
  final String? assistName;
  final String type;
  final String detail;

  EventDto({
    required this.minute,
    this.extraTime,
    required this.teamId,
    required this.teamName,
    required this.playerName,
    this.assistName,
    required this.type,
    required this.detail,
  });

  factory EventDto.fromJson(Map<String, dynamic> json) {
    final time = json['time'] as Map<String, dynamic>;
    final team = json['team'] as Map<String, dynamic>;
    final player = json['player'] as Map<String, dynamic>?;
    final assist = json['assist'] as Map<String, dynamic>?;

    return EventDto(
      minute: time['elapsed'] as int,
      extraTime: time['extra'] as int?,
      teamId: team['id'] as int,
      teamName: team['name'] as String,
      playerName: player?['name'] as String? ?? '',
      assistName: assist?['name'] as String?,
      type: json['type'] as String,
      detail: json['detail'] as String,
    );
  }

  MatchEvent toDomain(String matchId) {
    final EventType eventType;
    switch (type) {
      case 'Goal':
        eventType = EventType.goal;
      case 'Card':
        eventType = detail == 'Red Card' ? EventType.redCard : EventType.yellowCard;
      case 'subst':
        eventType = EventType.substitution;
      case 'Var':
        eventType = EventType.varDecision;
      default:
        eventType = EventType.goal;
    }

    return MatchEvent(
      id: '${matchId}_${minute}_${type}_${playerName}',
      minute: minute,
      type: eventType,
      teamId: '$teamId',
      playerName: playerName,
      assistPlayerName: assistName,
      replacedByPlayerName: type == 'subst' ? assistName : null,
    );
  }
}

/// DTO for API-Football /fixtures/lineups response items.
class LineupDto {
  final int teamId;
  final String teamName;
  final String? formation;
  final List<Player> startingXI;
  final List<Player> substitutes;
  final String? coachName;

  LineupDto({
    required this.teamId,
    required this.teamName,
    this.formation,
    required this.startingXI,
    required this.substitutes,
    this.coachName,
  });

  factory LineupDto.fromJson(Map<String, dynamic> json) {
    final team = json['team'] as Map<String, dynamic>;
    final startXI = json['startXI'] as List? ?? [];
    final subs = json['substitutes'] as List? ?? [];
    final coach = json['coach'] as Map<String, dynamic>?;

    return LineupDto(
      teamId: team['id'] as int,
      teamName: team['name'] as String,
      formation: json['formation'] as String?,
      startingXI: startXI
          .map((e) => _playerFromJson(e as Map<String, dynamic>))
          .toList(),
      substitutes: subs
          .map((e) => _playerFromJson(e as Map<String, dynamic>))
          .toList(),
      coachName: coach?['name'] as String?,
    );
  }

  static Player _playerFromJson(Map<String, dynamic> json) {
    final player = json['player'] as Map<String, dynamic>;
    return Player(
      id: '${player['id']}',
      name: player['name'] as String? ?? '',
      number: player['number'] as int? ?? 0,
      position: _mapPosition(player['pos'] as String?),
      photoUrl: player['photo'] as String?,
    );
  }

  static String _mapPosition(String? pos) {
    return switch (pos) {
      'GK' => 'Kaleci',
      'DF' => 'Defans',
      'MF' => 'Orta Saha',
      'FW' => 'Forvet',
      _ => 'Yedek',
    };
  }
}
