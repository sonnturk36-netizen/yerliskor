import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../core/constants/api_football_config.dart';
import '../../domain/entities/match.dart';
import '../models/api_football_dtos.dart';

/// Remote data source for API-Football v3.
class ApiFootballDataSource {
  ApiFootballDataSource({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  /// Fetches fixtures for all Turkish leagues for the given date.
  /// If [liveOnly] is true, fetches only currently live fixtures.
  Future<List<Match>> getFixtures({
    DateTime? date,
    bool liveOnly = false,
    int? leagueId,
    int? season,
    String? round,
    int? fixtureId,
    bool includeEvents = false,
    bool includeLineups = false,
  }) async {
    final results = <Match>[];
    final effectiveSeason = season ?? ApiFootballConfig.currentSeason;

    if (liveOnly) {
      // Fetch live fixtures across all Turkish leagues
      for (final lid in ApiFootballConfig.turkishLeagueIds) {
        final fixtures = await _fetchFixtures(
          leagueId: lid,
          season: effectiveSeason,
          live: true,
        );
        results.addAll(fixtures);
      }
    } else if (fixtureId != null) {
      // Single fixture by ID
      final fixtures = await _fetchFixtures(fixtureId: fixtureId);
      results.addAll(fixtures);
    } else if (leagueId != null) {
      final fixtures = await _fetchFixtures(
        leagueId: leagueId,
        season: effectiveSeason,
        round: round,
        date: date != null ? _formatDate(date) : null,
      );
      results.addAll(fixtures);
    } else {
      // Fetch by date across all Turkish leagues
      final dateStr = _formatDate(date ?? DateTime.now());
      for (final lid in ApiFootballConfig.turkishLeagueIds) {
        final fixtures = await _fetchFixtures(
          leagueId: lid,
          season: effectiveSeason,
          date: dateStr,
        );
        results.addAll(fixtures);
      }
    }

    // Enrich with events and lineups if requested
    if (includeEvents || includeLineups) {
      for (var i = 0; i < results.length; i++) {
        final match = results[i];
        List<MatchEvent>? events;
        List<Player>? homeXI, awayXI, homeBench, awayBench;

        if (includeEvents) {
          events = await getMatchEvents(int.parse(match.id));
        }
        if (includeLineups) {
          final lineups = await getMatchLineups(int.parse(match.id));
          if (lineups.length >= 2) {
            final homeLineup = lineups.firstWhere(
              (l) => l.teamId.toString() == match.homeTeam.id,
              orElse: () => lineups[0],
            );
            final awayLineup = lineups.firstWhere(
              (l) => l.teamId.toString() == match.awayTeam.id,
              orElse: () => lineups[1],
            );
            homeXI = homeLineup.startingXI;
            awayXI = awayLineup.startingXI;
            homeBench = homeLineup.substitutes;
            awayBench = awayLineup.substitutes;
          }
        }

        results[i] = Match(
          id: match.id,
          homeTeam: match.homeTeam,
          awayTeam: match.awayTeam,
          homeScore: match.homeScore,
          awayScore: match.awayScore,
          status: match.status,
          minute: match.minute,
          referee: match.referee,
          stadium: match.stadium,
          competition: match.competition,
          kickoffTime: match.kickoffTime,
          events: events ?? const [],
          homeStartingXI: homeXI ?? const [],
          awayStartingXI: awayXI ?? const [],
          homeBench: homeBench ?? const [],
          awayBench: awayBench ?? const [],
        );
      }
    }

    return results;
  }

  /// Fetches events for a specific fixture.
  Future<List<MatchEvent>> getMatchEvents(int fixtureId) async {
    final json = await _get('/fixtures/events', {'fixture': '$fixtureId'});
    final response = json['response'] as List? ?? [];
    return response
        .map((e) => EventDto.fromJson(e as Map<String, dynamic>).toDomain('$fixtureId'))
        .toList();
  }

  /// Fetches lineups for a specific fixture.
  Future<List<LineupDto>> getMatchLineups(int fixtureId) async {
    final json = await _get('/fixtures/lineups', {'fixture': '$fixtureId'});
    final response = json['response'] as List? ?? [];
    return response
        .map((e) => LineupDto.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<List<Match>> _fetchFixtures({
    int? leagueId,
    int? season,
    String? date,
    bool? live,
    String? round,
    int? fixtureId,
  }) async {
    final params = <String, String>{};
    if (fixtureId != null) params['id'] = '$fixtureId';
    if (leagueId != null) params['league'] = '$leagueId';
    if (season != null) params['season'] = '$season';
    if (date != null) params['date'] = date;
    if (live == true) params['live'] = 'all';
    if (round != null) params['round'] = round;
    params['timezone'] = ApiFootballConfig.timezone;

    final json = await _get('/fixtures', params);
    final response = json['response'] as List? ?? [];
    return response
        .map((e) => FixtureDto.fromJson(e as Map<String, dynamic>).toDomain())
        .toList();
  }

  /// Low-level GET with retry logic.
  Future<Map<String, dynamic>> _get(
    String endpoint,
    Map<String, String> params,
  ) async {
    final uri = Uri.parse('${ApiFootballConfig.baseUrl}$endpoint')
        .replace(queryParameters: params);

    final apiKey = ApiFootballConfig.apiKey;
    final headers = <String, String>{
      'x-apisports-key': apiKey,
    };

    for (var attempt = 0; attempt < ApiFootballConfig.maxRetries; attempt++) {
      try {
        final response = await _client
            .get(uri, headers: headers)
            .timeout(ApiFootballConfig.requestTimeout);

        if (response.statusCode == 200) {
          return jsonDecode(response.body) as Map<String, dynamic>;
        }

        if (response.statusCode == 429) {
          // Rate limited — wait longer before retry
          await Future.delayed(Duration(seconds: 5 * (attempt + 1)));
          continue;
        }

        if (response.statusCode >= 500) {
          // Server error — retry
          await Future.delayed(Duration(seconds: attempt + 1));
          continue;
        }

        // Client error — don't retry
        throw ApiException(
          'API error: ${response.statusCode}',
          statusCode: response.statusCode,
        );
      } on ApiException {
        rethrow;
      } catch (e) {
        if (attempt == ApiFootballConfig.maxRetries - 1) {
          throw NetworkException('Network error: $e');
        }
        await Future.delayed(Duration(seconds: attempt + 1));
      }
    }

    throw NetworkException('Max retries exceeded');
  }

  String _formatDate(DateTime date) {
    final y = date.year.toString().padLeft(4, '0');
    final m = date.month.toString().padLeft(2, '0');
    final d = date.day.toString().padLeft(2, '0');
    return '$y-$m-$d';
  }
}

class ApiException implements Exception {
  final String message;
  final int? statusCode;
  ApiException(this.message, {this.statusCode});
  @override
  String toString() => message;
}

class NetworkException implements Exception {
  final String message;
  NetworkException(this.message);
  @override
  String toString() => message;
}
