import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../../domain/entities/match.dart';

/// Local cache for match data, enabling offline support.
/// Stores fixtures as JSON in SharedPreferences with TTL.
class LocalCacheDataSource {
  static const _matchesKey = 'cached_matches';
  static const _matchesTimestampKey = 'cached_matches_ts';
  static const _matchDetailPrefix = 'cached_match_';
  static const _matchDetailTsPrefix = 'cached_match_ts_';

  final SharedPreferences _prefs;

  LocalCacheDataSource(this._prefs);

  // --- Match list cache ---

  Future<void> cacheMatches(List<Match> matches) async {
    final jsonList = matches.map((m) => _matchToJson(m)).toList();
    await _prefs.setString(_matchesKey, jsonEncode(jsonList));
    await _prefs.setInt(_matchesTimestampKey, DateTime.now().millisecondsSinceEpoch);
  }

  Future<List<Match>?> getCachedMatches({Duration maxAge = const Duration(minutes: 5)}) async {
    final stored = _prefs.getString(_matchesKey);
    if (stored == null) return null;

    final timestamp = _prefs.getInt(_matchesTimestampKey);
    if (timestamp != null) {
      final age = DateTime.now().millisecondsSinceEpoch - timestamp;
      if (age > maxAge.inMilliseconds) return null;
    }

    try {
      final jsonList = jsonDecode(stored) as List;
      return jsonList
          .map((e) => _matchFromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return null;
    }
  }

  Future<List<Match>?> getCachedMatchesStale() async {
    final stored = _prefs.getString(_matchesKey);
    if (stored == null) return null;

    try {
      final jsonList = jsonDecode(stored) as List;
      return jsonList
          .map((e) => _matchFromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return null;
    }
  }

  // --- Single match cache ---

  Future<void> cacheMatchDetail(Match match) async {
    await _prefs.setString('$_matchDetailPrefix${match.id}', jsonEncode(_matchToJson(match)));
    await _prefs.setInt(
      '$_matchDetailTsPrefix${match.id}',
      DateTime.now().millisecondsSinceEpoch,
    );
  }

  Future<Match?> getCachedMatchDetail(String id, {Duration maxAge = const Duration(minutes: 5)}) async {
    final stored = _prefs.getString('$_matchDetailPrefix$id');
    if (stored == null) return null;

    final timestamp = _prefs.getInt('$_matchDetailTsPrefix$id');
    if (timestamp != null) {
      final age = DateTime.now().millisecondsSinceEpoch - timestamp;
      if (age > maxAge.inMilliseconds) return null;
    }

    try {
      return _matchFromJson(jsonDecode(stored) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<Match?> getCachedMatchDetailStale(String id) async {
    final stored = _prefs.getString('$_matchDetailPrefix$id');
    if (stored == null) return null;
    try {
      return _matchFromJson(jsonDecode(stored) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  // --- Serialization ---

  Map<String, dynamic> _matchToJson(Match m) {
    return {
      'id': m.id,
      'homeTeam': {
        'id': m.homeTeam.id,
        'name': m.homeTeam.name,
        'shortName': m.homeTeam.shortName,
        'logoUrl': m.homeTeam.logoUrl,
      },
      'awayTeam': {
        'id': m.awayTeam.id,
        'name': m.awayTeam.name,
        'shortName': m.awayTeam.shortName,
        'logoUrl': m.awayTeam.logoUrl,
      },
      'homeScore': m.homeScore,
      'awayScore': m.awayScore,
      'status': m.status.name,
      'minute': m.minute,
      'referee': m.referee,
      'stadium': m.stadium,
      'competition': m.competition,
      'kickoffTime': m.kickoffTime?.toIso8601String(),
      'events': m.events.map(_eventToJson).toList(),
      'homeStartingXI': m.homeStartingXI.map(_playerToJson).toList(),
      'awayStartingXI': m.awayStartingXI.map(_playerToJson).toList(),
      'homeBench': m.homeBench.map(_playerToJson).toList(),
      'awayBench': m.awayBench.map(_playerToJson).toList(),
    };
  }

  Match _matchFromJson(Map<String, dynamic> json) {
    return Match(
      id: json['id'] as String,
      homeTeam: _teamFromJson(json['homeTeam'] as Map<String, dynamic>),
      awayTeam: _teamFromJson(json['awayTeam'] as Map<String, dynamic>),
      homeScore: json['homeScore'] as int,
      awayScore: json['awayScore'] as int,
      status: MatchStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => MatchStatus.scheduled,
      ),
      minute: json['minute'] as int,
      referee: json['referee'] as String?,
      stadium: json['stadium'] as String?,
      competition: json['competition'] as String,
      kickoffTime: json['kickoffTime'] != null
          ? DateTime.parse(json['kickoffTime'] as String)
          : null,
      events: (json['events'] as List? ?? [])
          .map((e) => _eventFromJson(e as Map<String, dynamic>))
          .toList(),
      homeStartingXI: (json['homeStartingXI'] as List? ?? [])
          .map((e) => _playerFromJson(e as Map<String, dynamic>))
          .toList(),
      awayStartingXI: (json['awayStartingXI'] as List? ?? [])
          .map((e) => _playerFromJson(e as Map<String, dynamic>))
          .toList(),
      homeBench: (json['homeBench'] as List? ?? [])
          .map((e) => _playerFromJson(e as Map<String, dynamic>))
          .toList(),
      awayBench: (json['awayBench'] as List? ?? [])
          .map((e) => _playerFromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  Team _teamFromJson(Map<String, dynamic> json) {
    return Team(
      id: json['id'] as String,
      name: json['name'] as String,
      shortName: json['shortName'] as String,
      logoUrl: json['logoUrl'] as String?,
    );
  }

  Map<String, dynamic> _eventToJson(MatchEvent e) {
    return {
      'id': e.id,
      'minute': e.minute,
      'type': e.type.name,
      'teamId': e.teamId,
      'playerName': e.playerName,
      'assistPlayerName': e.assistPlayerName,
      'replacedByPlayerName': e.replacedByPlayerName,
    };
  }

  MatchEvent _eventFromJson(Map<String, dynamic> json) {
    return MatchEvent(
      id: json['id'] as String,
      minute: json['minute'] as int,
      type: EventType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => EventType.goal,
      ),
      teamId: json['teamId'] as String,
      playerName: json['playerName'] as String,
      assistPlayerName: json['assistPlayerName'] as String?,
      replacedByPlayerName: json['replacedByPlayerName'] as String?,
    );
  }

  Map<String, dynamic> _playerToJson(Player p) {
    return {
      'id': p.id,
      'name': p.name,
      'number': p.number,
      'position': p.position,
      'photoUrl': p.photoUrl,
    };
  }

  Player _playerFromJson(Map<String, dynamic> json) {
    return Player(
      id: json['id'] as String,
      name: json['name'] as String,
      number: json['number'] as int,
      position: json['position'] as String,
      photoUrl: json['photoUrl'] as String?,
    );
  }
}
