import '../../domain/entities/match.dart';
import '../datasources/api_football_data_source.dart';
import '../datasources/local_cache_data_source.dart';

/// Repository contract — UI and use cases depend on this abstraction.
abstract class MatchRepository {
  Future<List<Match>> getMatches({bool forceRefresh});
  Future<Match?> getMatchById(String id, {bool forceRefresh});
  Future<List<Match>> getLiveMatches();
}

/// Production repository backed by API-Football with local caching.
///
/// Strategy:
/// 1. Return fresh API data on success.
/// 2. On network failure, fall back to cached data (stale-while-error).
/// 3. Cache every successful response for offline use.
class FootballRepositoryImpl implements MatchRepository {
  FootballRepositoryImpl({
    required ApiFootballDataSource remoteDataSource,
    required LocalCacheDataSource localCacheDataSource,
  })  : _remote = remoteDataSource,
        _cache = localCacheDataSource;

  final ApiFootballDataSource _remote;
  final LocalCacheDataSource _cache;

  @override
  Future<List<Match>> getMatches({bool forceRefresh = false}) async {
    // Try cache first (unless forced refresh)
    if (!forceRefresh) {
      final cached = await _cache.getCachedMatches();
      if (cached != null && cached.isNotEmpty) return cached;
    }

    try {
      final matches = await _remote.getFixtures(
        date: DateTime.now(),
        includeEvents: false,
        includeLineups: false,
      );
      await _cache.cacheMatches(matches);
      return matches;
    } catch (e) {
      // Fall back to stale cache on network error
      final stale = await _cache.getCachedMatchesStale();
      if (stale != null && stale.isNotEmpty) return stale;
      rethrow;
    }
  }

  @override
  Future<Match?> getMatchById(String id, {bool forceRefresh = false}) async {
    if (!forceRefresh) {
      final cached = await _cache.getCachedMatchDetail(id);
      if (cached != null) return cached;
    }

    try {
      final matches = await _remote.getFixtures(
        fixtureId: int.tryParse(id),
        includeEvents: true,
        includeLineups: true,
      );
      if (matches.isNotEmpty) {
        final match = matches.first;
        await _cache.cacheMatchDetail(match);
        return match;
      }
      return null;
    } catch (e) {
      final stale = await _cache.getCachedMatchDetailStale(id);
      if (stale != null) return stale;
      rethrow;
    }
  }

  @override
  Future<List<Match>> getLiveMatches() async {
    try {
      return await _remote.getFixtures(liveOnly: true);
    } catch (e) {
      // Fall back to cached matches and filter live ones
      final cached = await _cache.getCachedMatchesStale();
      if (cached != null) {
        return cached.where((m) => m.isLive).toList();
      }
      rethrow;
    }
  }
}
