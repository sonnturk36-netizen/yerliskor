import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/theme/app_theme.dart';
import 'data/datasources/api_football_data_source.dart';
import 'data/datasources/local_cache_data_source.dart';
import 'data/repositories/football_repository_impl.dart';
import 'domain/usecases/get_match_by_id.dart';
import 'domain/usecases/get_matches.dart';
import 'presentation/main/main_shell.dart';
import 'presentation/splash/splash_screen.dart';
import 'services/goal_sound_service.dart';
import 'services/match_polling_service.dart';
import 'services/notification_service.dart';
import 'services/permission_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await dotenv.load(fileName: '.env');
  } catch (_) {
    // .env not found — API key must be provided via --dart-define
  }

  final prefs = await SharedPreferences.getInstance();

  runApp(YerliSkorApp(prefs: prefs));
}

class YerliSkorApp extends StatefulWidget {
  final SharedPreferences prefs;

  const YerliSkorApp({super.key, required this.prefs});

  @override
  State<YerliSkorApp> createState() => _YerliSkorAppState();
}

class _YerliSkorAppState extends State<YerliSkorApp> {
  bool _showSplash = true;
  bool _initialized = false;

  late final FootballRepositoryImpl _matchRepository;
  late final NotificationService _notificationService;
  late final GoalSoundService _goalSoundService;
  late final PermissionService _permissionService;
  late final MatchPollingService _pollingService;

  @override
  void initState() {
    super.initState();
    _setupServices();
    _bootstrap();
  }

  void _setupServices() {
    _notificationService = NotificationService();
    _goalSoundService = GoalSoundService();
    _permissionService = PermissionService();

    final remoteDataSource = ApiFootballDataSource();
    final cache = LocalCacheDataSource(widget.prefs);

    _matchRepository = FootballRepositoryImpl(
      remoteDataSource: remoteDataSource,
      localCacheDataSource: cache,
    );

    _pollingService = MatchPollingService(
      repository: _matchRepository,
      notificationService: _notificationService,
    );
  }

  Future<void> _bootstrap() async {
    await _notificationService.init();

    final shouldRequest =
        await _permissionService.shouldRequestNotificationPermission();
    if (shouldRequest) {
      await _permissionService.requestNotificationPermission();
    }

    _pollingService.start();

    if (mounted) {
      setState(() => _initialized = true);
    }
  }

  void _onSplashComplete() {
    if (mounted) {
      setState(() => _showSplash = false);
    }
  }

  @override
  void dispose() {
    _pollingService.dispose();
    _goalSoundService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<FootballRepositoryImpl>.value(value: _matchRepository),
        Provider<GetMatches>(
          create: (_) => GetMatches(_matchRepository),
        ),
        Provider<GetMatchById>(
          create: (_) => GetMatchById(_matchRepository),
        ),
        ChangeNotifierProvider<NotificationService>.value(
          value: _notificationService,
        ),
        ChangeNotifierProvider<MatchPollingService>.value(
          value: _pollingService,
        ),
        Provider<GoalSoundService>.value(value: _goalSoundService),
        Provider<PermissionService>.value(value: _permissionService),
      ],
      child: MaterialApp(
        title: 'YerliSkor',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        home: _showSplash || !_initialized
            ? SplashScreen(onComplete: _onSplashComplete)
            : const MainShell(),
      ),
    );
  }
}
