enum NotificationType {
  goal,
  matchStarted,
  halfTime,
  secondHalfStarted,
  redCard,
  yellowCard,
  fullTime,
}

class AppNotification {
  final String id;
  final NotificationType type;
  final String title;
  final String body;
  final String? matchId;
  final DateTime timestamp;
  final bool read;

  AppNotification({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    this.matchId,
    required this.timestamp,
    this.read = false,
  });

  AppNotification copyWith({bool? read}) {
    return AppNotification(
      id: id,
      type: type,
      title: title,
      body: body,
      matchId: matchId,
      timestamp: timestamp,
      read: read ?? this.read,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type.name,
      'title': title,
      'body': body,
      'matchId': matchId,
      'timestamp': timestamp.toIso8601String(),
      'read': read,
    };
  }

  factory AppNotification.fromJson(Map<String, dynamic> json) {
    return AppNotification(
      id: json['id'] as String,
      type: NotificationType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => NotificationType.goal,
      ),
      title: json['title'] as String,
      body: json['body'] as String,
      matchId: json['matchId'] as String?,
      timestamp: DateTime.parse(json['timestamp'] as String),
      read: json['read'] as bool? ?? false,
    );
  }
}
