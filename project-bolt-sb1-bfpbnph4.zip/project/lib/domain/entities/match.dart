enum MatchStatus {
  scheduled,
  live,
  halftime,
  finished,
  postponed,
}

class Team {
  final String id;
  final String name;
  final String shortName;
  final String? logoUrl;
  final String? primaryColor;

  const Team({
    required this.id,
    required this.name,
    required this.shortName,
    this.logoUrl,
    this.primaryColor,
  });
}

class Player {
  final String id;
  final String name;
  final int number;
  final String position;
  final String? photoUrl;

  const Player({
    required this.id,
    required this.name,
    required this.number,
    required this.position,
    this.photoUrl,
  });
}

enum EventType {
  goal,
  yellowCard,
  redCard,
  substitution,
  varDecision,
}

class MatchEvent {
  final String id;
  final int minute;
  final EventType type;
  final String teamId;
  final String playerName;
  final String? assistPlayerName;
  final String? replacedByPlayerName;

  const MatchEvent({
    required this.id,
    required this.minute,
    required this.type,
    required this.teamId,
    required this.playerName,
    this.assistPlayerName,
    this.replacedByPlayerName,
  });
}

class Match {
  final String id;
  final Team homeTeam;
  final Team awayTeam;
  final int homeScore;
  final int awayScore;
  final MatchStatus status;
  final int minute;
  final String? referee;
  final String? stadium;
  final String competition;
  final DateTime? kickoffTime;
  final List<MatchEvent> events;
  final List<Player> homeStartingXI;
  final List<Player> awayStartingXI;
  final List<Player> homeBench;
  final List<Player> awayBench;

  const Match({
    required this.id,
    required this.homeTeam,
    required this.awayTeam,
    required this.homeScore,
    required this.awayScore,
    required this.status,
    required this.minute,
    this.referee,
    this.stadium,
    required this.competition,
    this.kickoffTime,
    this.events = const [],
    this.homeStartingXI = const [],
    this.awayStartingXI = const [],
    this.homeBench = const [],
    this.awayBench = const [],
  });

  bool get isLive => status == MatchStatus.live || status == MatchStatus.halftime;
}
