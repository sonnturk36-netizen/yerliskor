import '../../data/repositories/football_repository_impl.dart';
import '../entities/match.dart';

class GetMatchById {
  final MatchRepository repository;
  GetMatchById(this.repository);

  Future<Match?> call(String id, {bool forceRefresh = false}) {
    return repository.getMatchById(id, forceRefresh: forceRefresh);
  }
}
