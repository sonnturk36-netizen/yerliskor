import '../../data/repositories/football_repository_impl.dart';
import '../entities/match.dart';

class GetMatches {
  final MatchRepository repository;
  GetMatches(this.repository);

  Future<List<Match>> call({bool forceRefresh = false}) async {
    final matches = await repository.getMatches(forceRefresh: forceRefresh);
    matches.sort((a, b) {
      if (a.isLive && !b.isLive) return -1;
      if (!a.isLive && b.isLive) return 1;
      if (a.isLive && b.isLive) return b.minute.compareTo(a.minute);
      return (a.kickoffTime ?? DateTime.now())
          .compareTo(b.kickoffTime ?? DateTime.now());
    });
    return matches;
  }
}
