# YerliSkor

Türk futbolu için canlı skor uygulaması — API-Football entegrasyonu.

## Kurulum

### 1. API Anahtarı

[api-football.com](https://dashboard.api-football.com/) üzerinden API anahtarı alın ve `.env` dosyasına ekleyin:

```
API_FOOTBALL_KEY=sizin_anahtarınız
```

Alternatif olarak, derleme sırasında tanımlayabilirsiniz:

```bash
flutter run --dart-define=API_FOOTBALL_KEY=sizin_anahtarınız
```

### 2. Çalıştırma

```bash
flutter pub get
flutter run
```

## Yapı

```
lib/
├── core/
│   ├── constants/
│   │   ├── api_football_config.dart  # API yapılandırması + lig ID'leri
│   │   ├── app_colors.dart           # Renk paleti
│   │   └── app_constants.dart        # Sabitler
│   ├── theme/                        # Material tema
│   └── widgets/                      # Yeniden kullanılabilir widget'lar
├── data/
│   ├── datasources/
│   │   ├── api_football_data_source.dart  # API-Football HTTP istemcisi
│   │   └── local_cache_data_source.dart   # SharedPreferences çevrimdışı önbellek
│   ├── models/
│   │   └── api_football_dtos.dart          # JSON → domain DTO'lar
│   └── repositories/
│       └── football_repository_impl.dart   # Repository (cache + fallback)
├── domain/
│   ├── entities/                     # Match, Team, Player, AppNotification
│   └── usecases/                     # GetMatches, GetMatchById
├── presentation/
│   ├── splash/                       # Splash ekranı
│   ├── main/                         # Main shell, app bar, live banner
│   ├── matches/                      # Maç listesi + kart widget'ları
│   ├── match_details/                # Maç detayı + timeline, lineup
│   └── notifications/               # Bildirim geçmişi
└── services/
    ├── api_football_data_source.dart
    ├── match_polling_service.dart    # Otomatik güncelleme + bildirim tetikleyici
    ├── notification_service.dart     # Yerel push bildirimleri
    ├── goal_sound_service.dart       # Gol sesi çalma
    └── permission_service.dart        # Bildirim izni
```

## Desteklenen Ligler

| Lig | ID |
|-----|---|
| Trendyol Süper Lig | 203 |
| Trendyol 1. Lig | 204 |
| TFF 2. Lig | 205 |
| TFF 3. Lig | 206 |
| Ziraat Türkiye Kupası | 207 |

## Özellikler

- Canlı skorlar (30 saniyede bir otomatik güncelleme)
- Maç dakikası güncellemeleri
- Resmi takım logoları
- Maç olayları: goller, sarı kartlar, kırmızı kartlar, oyuncu değişiklikleri
- İlk 11 ve yedek oyuncular
- Hakem ve stadyum bilgisi
- Otomatik bildirimler: Gol, Maç Başladı, Devre Arası, İkinci Yarı, Kırmızı Kart, Sarı Kart, Maç Bitti
- Çevrimdışı önbellek (stale-while-error)
- Yeniden deneme desteği
- Yükleme ve hata durumları

## Gol Sesi

`assets/sounds/` klasörüne şu dosyaları ekleyin:
- `kick.mp3` — Futbol vuruşu
- `net.mp3` — Ağ sesi
- `cheer.mp3` — Tribün tezahüratı
- `gool.mp3` — "GOOOL!" sesi
- `goal_combined.mp3` — Birleşik gol sesi (placeholder)
