/// <reference types="vite/client" />

export const TURKISH_LEAGUES: Record<number, string> = {
  203: 'Trendyol Süper Lig',
  204: 'Trendyol 1. Lig',
  205: 'TFF 2. Lig',
  206: 'TFF 3. Lig',
  207: 'Ziraat Türkiye Kupası',
};

export const TURKISH_LEAGUE_IDS = [203, 204, 205, 206, 207];

export const API_BASE = 'https://v3.football.api-sports.io';

export const POLL_INTERVAL_MS = 30_000;

/** Reads API_FOOTBALL_KEY from import.meta.env (set via .env file as VITE_API_FOOTBALL_KEY) */
export function getApiKey(): string {
  return import.meta.env.VITE_API_FOOTBALL_KEY ?? '';
}

export function isApiKeyConfigured(): boolean {
  const key = getApiKey();
  return key.length > 0 && key !== 'YOUR_API_KEY_HERE';
}

export function getCurrentSeason(): number {
  const now = new Date();
  return now.getMonth() >= 6 ? now.getFullYear() : now.getFullYear() - 1;
}
