import type { Match } from '../types';

export function getPlaceholderMatches(): Match[] {
  return [
    {
      id: 'demo1',
      homeTeam: { id: 'gs', name: 'Galatasaray', shortName: 'GS', logoUrl: 'https://media.api-sports.io/football/teams/627.png' },
      awayTeam: { id: 'fb', name: 'Fenerbahçe', shortName: 'FB', logoUrl: 'https://media.api-sports.io/football/teams/628.png' },
      homeScore: 2, awayScore: 1,
      status: 'live', minute: 78,
      referee: 'Cüneyt Çakır', stadium: 'RAMS Park, İstanbul',
      competition: 'Trendyol Süper Lig', leagueId: 203,
      round: 'Regular Season - 12',
      events: [
        { id: 'e1', minute: 12, type: 'goal', teamId: 'gs', playerName: 'Icardi', assistPlayerName: 'Mertens', detail: 'Normal Goal' },
        { id: 'e2', minute: 34, type: 'yellowCard', teamId: 'fb', playerName: 'Szysz' },
        { id: 'e3', minute: 55, type: 'goal', teamId: 'fb', playerName: 'Tadić', detail: 'Normal Goal' },
        { id: 'e4', minute: 72, type: 'substitution', teamId: 'gs', playerName: 'Mertens', replacedByPlayerName: 'Zaha' },
        { id: 'e5', minute: 78, type: 'goal', teamId: 'gs', playerName: 'Icardi', assistPlayerName: 'Zaha', detail: 'Normal Goal' },
      ],
      homeStartingXI: makePlayers('gs', ['Muslera', 'Boey', 'Sanchez', 'Abdulkerim', 'Angelino', 'Lemina', 'Torreira', 'Mertens', 'Zaha', 'Icardi', 'Yunus'], ['GK','DF','DF','DF','DF','MF','MF','FW','FW','FW','FW']),
      awayStartingXI: makePlayers('fb', ['Livakovic', 'Tadic', 'Szysz', 'Rodrigues', 'Osayi', 'Fred', 'Amrabat', 'En-Nesyri', 'Irfan', 'Dzeko', 'Cengiz'], ['GK','FW','MF','DF','DF','MF','MF','FW','FW','FW','FW']),
      homeBench: makePlayers('gs_b', ['Günok', 'Sallai', 'Bardhi', 'Kerem', 'Nelsson', 'Morutan', 'Lucas'], ['GK','FW','MF','FW','DF','MF','DF']),
      awayBench: makePlayers('fb_b', ['Harun', 'Bright', 'Mert', 'Yandaş', 'Lincoln', 'Under', 'Jayden'], ['GK','MF','DF','MF','FW','FW','FW']),
    },
    {
      id: 'demo2',
      homeTeam: { id: 'bjk', name: 'Beşiktaş', shortName: 'BJK', logoUrl: 'https://media.api-sports.io/football/teams/630.png' },
      awayTeam: { id: 'ts', name: 'Trabzonspor', shortName: 'TS', logoUrl: 'https://media.api-sports.io/football/teams/631.png' },
      homeScore: 1, awayScore: 1,
      status: 'halftime', minute: 45,
      referee: 'Halil Umut Meler', stadium: 'Tüpraş Stadyumu, İstanbul',
      competition: 'Trendyol Süper Lig', leagueId: 203,
      round: 'Regular Season - 12',
      events: [
        { id: 'e6', minute: 22, type: 'goal', teamId: 'bjk', playerName: 'İmaloren', detail: 'Normal Goal' },
        { id: 'e7', minute: 40, type: 'goal', teamId: 'ts', playerName: 'Enis Destan', detail: 'Normal Goal' },
      ],
      homeStartingXI: makePlayers('bjk', ['Mert', 'Rosier', 'Necip', 'Ghezzal', 'Rebocho', 'Souza', 'Al Musrati', 'Gedson', 'Onana', 'İmaloren', 'Semih'], ['GK','DF','DF','MF','DF','MF','MF','MF','FW','FW','FW']),
      awayStartingXI: makePlayers('ts', ['Uğurcan', 'Vitor', 'Mečanin', 'Hosseini', 'Berat', 'Bakasetas', 'Dorukhan', 'Trezeguet', 'Djaniny', 'Destan', 'Visca'], ['GK','DF','DF','DF','DF','MF','MF','MF','FW','FW','FW']),
      homeBench: makePlayers('bjk_b', ['Ersin', 'Elneny', 'Can', 'Salih', 'Babel', 'Batshuayi', 'Riza'], ['GK','MF','DF','MF','FW','FW','MF']),
      awayBench: makePlayers('ts_b', ['Blažič', 'Kliber', 'Gervinho', 'Nwakaeme', 'Stefanović', 'Pepe', 'Silva'], ['GK','DF','FW','FW','DF','DF','MF']),
    },
    {
      id: 'demo3',
      homeTeam: { id: 'ibfk', name: 'Başakşehir', shortName: 'İBFK', logoUrl: 'https://media.api-sports.io/football/teams/635.png' },
      awayTeam: { id: 'ant', name: 'Antalyaspor', shortName: 'ANT', logoUrl: 'https://media.api-sports.io/football/teams/641.png' },
      homeScore: 0, awayScore: 0,
      status: 'live', minute: 23,
      referee: 'Mustafa Murat Ilgaz', stadium: 'Başakşehir Fatih Terim Stadyumu, İstanbul',
      competition: 'Trendyol Süper Lig', leagueId: 203,
      round: 'Regular Season - 12',
      events: [
        { id: 'e8', minute: 15, type: 'yellowCard', teamId: 'ant', playerName: 'Bük' },
      ],
      homeStartingXI: makePlayers('ibfk', ['Günok', 'Junior', 'Skrtel', 'Epureanu', 'Clichy', 'Visca', 'Sosa', 'Tekdemir', 'Chadli', 'Giuliano', 'Robinho'], ['GK','DF','DF','DF','DF','FW','MF','MF','MF','MF','FW']),
      awayStartingXI: makePlayers('ant', ['Runje', 'Pehlivan', 'Weiss', 'Pereira', 'Samir', 'Bük', 'Emre', 'Paulo', 'Jahovic', 'Yatabare', 'Podolski'], ['GK','DF','DF','DF','DF','MF','MF','MF','FW','FW','FW']),
      homeBench: makePlayers('ibfk_b', ['Mert', 'Sokol', 'Arda', 'Turhan', 'Elia', 'Aziz', 'Rafael'], ['GK','DF','MF','MF','FW','FW','DF']),
      awayBench: makePlayers('ant_b', ['Muhammed', 'Kouyate', 'Mbemba', 'Arango', 'Hanche', 'Eto', 'Thomas'], ['GK','DF','DF','FW','DF','FW','MF']),
    },
    {
      id: 'demo4',
      homeTeam: { id: 'fb2', name: 'Fenerbahçe', shortName: 'FB', logoUrl: 'https://media.api-sports.io/football/teams/628.png' },
      awayTeam: { id: 'bjk2', name: 'Beşiktaş', shortName: 'BJK', logoUrl: 'https://media.api-sports.io/football/teams/630.png' },
      homeScore: 3, awayScore: 0,
      status: 'finished', minute: 90,
      referee: 'Cüneyt Çakır', stadium: 'Ülker Stadyumu, İstanbul',
      competition: 'Trendyol Süper Lig', leagueId: 203,
      round: 'Regular Season - 11',
      events: [
        { id: 'e9', minute: 8, type: 'goal', teamId: 'fb2', playerName: 'Tadić', detail: 'Normal Goal' },
        { id: 'e10', minute: 44, type: 'redCard', teamId: 'bjk2', playerName: 'Necip' },
        { id: 'e11', minute: 67, type: 'goal', teamId: 'fb2', playerName: 'Fred', detail: 'Normal Goal' },
        { id: 'e12', minute: 85, type: 'goal', teamId: 'fb2', playerName: 'En-Nesyri', detail: 'Normal Goal' },
      ],
      homeStartingXI: [], awayStartingXI: [], homeBench: [], awayBench: [],
    },
  ];
}

function makePlayers(prefix: string, names: string[], positions: string[]) {
  return names.map((name, i) => ({
    id: `${prefix}_${i}`,
    name,
    number: i + 1,
    position: mapPos(positions[i] ?? 'MF'),
  }));
}

function mapPos(pos: string): string {
  switch (pos) {
    case 'GK': return 'Kaleci';
    case 'DF': return 'Defans';
    case 'MF': return 'Orta Saha';
    case 'FW': return 'Forvet';
    default: return 'Yedek';
  }
}
