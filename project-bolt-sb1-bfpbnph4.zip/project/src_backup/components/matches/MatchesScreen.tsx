import { useMatchStore } from '../../store/matches';
import { useMatchPolling } from '../../hooks/useMatchPolling';
import { isApiKeyConfigured } from '../../services/config';
import { MatchCard } from './MatchCard';
import { SectionHeader } from '../ui/SectionHeader';
import type { Match } from '../../types';

interface MatchesScreenProps {
  onMatchClick: (match: Match) => void;
}

export function MatchesScreen({ onMatchClick }: MatchesScreenProps) {
  const { matches, loading, error } = useMatchStore();
  const { refresh } = useMatchPolling();

  const liveMatches = matches.filter(m => m.status === 'live' || m.status === 'halftime');
  const otherMatches = matches.filter(m => m.status !== 'live' && m.status !== 'halftime');
  const noApiKey = !isApiKeyConfigured();

  if (loading && matches.length === 0) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 16 }}>
        <div style={{
          width: 40, height: 40, borderRadius: '50%',
          border: '3px solid var(--divider)',
          borderTopColor: 'var(--primary)',
          animation: 'spin 0.8s linear infinite',
        }} />
        <span style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Maçlar yükleniyor...</span>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (error && matches.length === 0) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 12, padding: 32, textAlign: 'center' }}>
        <svg width={48} height={48} viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" strokeWidth={1.5}>
          <path d="M1 1l22 22M16.72 11.06A10.94 10.94 0 0 1 19 12.55M5 12.55a10.94 10.94 0 0 1 5.17-2.39M10.71 5.05A16 16 0 0 1 22.56 9M1.42 9a15.91 15.91 0 0 1 4.7-2.88M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/>
        </svg>
        <span style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-secondary)' }}>Maçlar yüklenemedi</span>
        <span style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>{error}</span>
        <button onClick={refresh} style={{
          background: 'var(--primary)', color: '#fff', border: 'none', borderRadius: 10,
          padding: '10px 20px', fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins',
        }}>
          Tekrar Dene
        </button>
      </div>
    );
  }

  return (
    <div className="scroll-area" style={{ padding: '0 16px' }}>
      {noApiKey && (
        <div style={{
          background: 'rgba(249,168,37,0.12)', border: '1px solid rgba(249,168,37,0.4)',
          borderRadius: 12, padding: '10px 14px', margin: '12px 0',
          display: 'flex', alignItems: 'flex-start', gap: 10,
        }}>
          <span style={{ fontSize: 18 }}>🔑</span>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#c68400' }}>Demo Modu</div>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 2 }}>
              Gerçek verileri görmek için .env dosyasına VITE_API_FOOTBALL_KEY ekleyin.
            </div>
          </div>
        </div>
      )}

      {liveMatches.length > 0 && (
        <>
          <SectionHeader
            title="Canlı Maçlar"
            icon={<svg width={17} height={17} viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/></svg>}
          />
          {liveMatches.map((m, i) => (
            <MatchCard key={m.id} match={m} onClick={() => onMatchClick(m)} index={i} />
          ))}
        </>
      )}

      {otherMatches.length > 0 && (
        <>
          <SectionHeader
            title="Diğer Maçlar"
            icon={<svg width={17} height={17} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>}
            color="var(--text-tertiary)"
          />
          {otherMatches.map((m, i) => (
            <MatchCard key={m.id} match={m} onClick={() => onMatchClick(m)} index={i} />
          ))}
        </>
      )}

      {matches.length === 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, marginTop: 80, textAlign: 'center' }}>
          <svg width={64} height={64} viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" strokeWidth={1.2}>
            <circle cx="12" cy="12" r="10"/>
            <path d="M12 2a10 10 0 0 1 7.07 17.07M12 2a10 10 0 0 0-7.07 17.07"/>
          </svg>
          <span style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-secondary)' }}>Şu anda canlı maç yok</span>
          <span style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>Maçlar başladığında burada görünecek</span>
        </div>
      )}

      <div style={{ height: 24 }} />
    </div>
  );
}
