import type { Match } from '../../types';
import { TeamLogo } from '../ui/TeamLogo';
import { LiveBadge } from '../ui/LiveBadge';

interface MatchCardProps {
  match: Match;
  onClick: () => void;
  index?: number;
}

export function MatchCard({ match, onClick, index = 0 }: MatchCardProps) {
  return (
    <div
      className="card animate-slide-in"
      style={{
        marginBottom: 12,
        cursor: 'pointer',
        animationDelay: `${index * 60}ms`,
        WebkitTapHighlightColor: 'transparent',
      }}
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={e => e.key === 'Enter' && onClick()}
    >
      <div style={{ padding: '14px 16px' }}>
        {/* Competition row */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <span style={{ fontSize: 11, fontWeight: 500, color: 'var(--text-tertiary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1, marginRight: 8 }}>
            {match.competition}{match.round ? ` · ${match.round.replace('Regular Season - ', 'Hf.')}` : ''}
          </span>
          <LiveBadge status={match.status} minute={match.minute} />
        </div>

        {/* Teams and score */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {/* Home team */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <TeamLogo logoUrl={match.homeTeam.logoUrl} fallback={match.homeTeam.shortName} size={44} />
            <span style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text)', textAlign: 'center', lineHeight: 1.3 }}>
              {match.homeTeam.name}
            </span>
          </div>

          {/* Score box */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            background: 'var(--bg)',
            borderRadius: 10,
            padding: '8px 14px',
            gap: 0,
            flexShrink: 0,
          }}>
            <span style={{ fontSize: 28, fontWeight: 700, color: 'var(--text)', lineHeight: 1 }}>
              {match.homeScore}
            </span>
            <div style={{ width: 1, height: 24, background: 'var(--divider)', margin: '0 8px' }} />
            <span style={{ fontSize: 28, fontWeight: 700, color: 'var(--text)', lineHeight: 1 }}>
              {match.awayScore}
            </span>
          </div>

          {/* Away team */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <TeamLogo logoUrl={match.awayTeam.logoUrl} fallback={match.awayTeam.shortName} size={44} />
            <span style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--text)', textAlign: 'center', lineHeight: 1.3 }}>
              {match.awayTeam.name}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
