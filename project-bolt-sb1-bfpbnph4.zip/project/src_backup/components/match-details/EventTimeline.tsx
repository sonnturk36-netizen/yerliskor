import type { Match, MatchEvent } from '../../types';

interface EventTimelineProps {
  match: Match;
}

export function EventTimeline({ match }: EventTimelineProps) {
  const events = [...match.events].sort((a, b) => a.minute - b.minute);

  if (events.length === 0) {
    return (
      <div style={{ textAlign: 'center', color: 'var(--text-tertiary)', fontSize: 13, padding: '8px 0' }}>
        Henüz olay yok
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
      {events.map(e => (
        <EventRow key={e.id} event={e} match={match} />
      ))}
    </div>
  );
}

function EventRow({ event, match }: { event: MatchEvent; match: Match }) {
  const isHome = event.teamId === match.homeTeam.id;
  const { icon, color, label } = eventMeta(event);
  const teamShort = isHome ? match.homeTeam.shortName : match.awayTeam.shortName;

  return (
    <div style={{
      display: 'flex',
      alignItems: 'flex-start',
      gap: 0,
      marginBottom: 14,
      flexDirection: isHome ? 'row' : 'row-reverse',
    }}>
      {/* Minute */}
      <div style={{ width: 44, flexShrink: 0, textAlign: 'center', paddingTop: 2 }}>
        <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--primary)' }}>
          {event.minute}'
          {event.extraTime ? `+${event.extraTime}` : ''}
        </span>
      </div>

      {/* Line */}
      <div style={{ width: 1, background: 'var(--divider)', alignSelf: 'stretch', margin: '0 0 0 0', flexShrink: 0 }} />

      {/* Content */}
      <div style={{
        flex: 1,
        display: 'flex',
        alignItems: 'flex-start',
        gap: 8,
        paddingLeft: isHome ? 12 : 0,
        paddingRight: isHome ? 0 : 12,
        flexDirection: isHome ? 'row' : 'row-reverse',
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: 8, flexShrink: 0,
          background: `${color}1e`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 14,
        }}>
          {icon}
        </div>
        <div style={{ flex: 1, textAlign: isHome ? 'left' : 'right' }}>
          <div style={{ fontSize: 13.5, fontWeight: 600, color: 'var(--text)' }}>{label}</div>
          <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 1 }}>{teamShort}</div>
        </div>
      </div>
    </div>
  );
}

function eventMeta(event: MatchEvent): { icon: string; color: string; label: string } {
  switch (event.type) {
    case 'goal':
      return {
        icon: '⚽',
        color: '#D50000',
        label: `GOL · ${event.playerName}${event.assistPlayerName ? ` (${event.assistPlayerName})` : ''}`,
      };
    case 'yellowCard':
      return { icon: '🟨', color: '#FBC02D', label: `Sarı Kart · ${event.playerName}` };
    case 'redCard':
      return { icon: '🟥', color: '#D50000', label: `Kırmızı Kart · ${event.playerName}` };
    case 'substitution':
      return {
        icon: '🔄',
        color: '#6B6B6B',
        label: `${event.playerName} ➜ ${event.replacedByPlayerName ?? ''}`,
      };
    case 'varDecision':
      return { icon: '📺', color: '#6B6B6B', label: `VAR · ${event.playerName}` };
  }
}
