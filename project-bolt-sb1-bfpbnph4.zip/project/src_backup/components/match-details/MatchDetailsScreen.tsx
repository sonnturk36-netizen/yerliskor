import { useState, useEffect } from 'react';
import type { Match } from '../../types';
import { fetchMatchDetails } from '../../services/apiFootball';
import { isApiKeyConfigured } from '../../services/config';
import { TeamLogo } from '../ui/TeamLogo';
import { LiveBadge } from '../ui/LiveBadge';
import { SectionHeader } from '../ui/SectionHeader';
import { EventTimeline } from './EventTimeline';
import { LineupView } from './LineupView';

interface MatchDetailsScreenProps {
  match: Match;
  onBack: () => void;
}

export function MatchDetailsScreen({ match: initialMatch, onBack }: MatchDetailsScreenProps) {
  const [match, setMatch] = useState<Match>(initialMatch);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isApiKeyConfigured()) return;
    setLoading(true);
    fetchMatchDetails(initialMatch.id)
      .then(data => { if (data) setMatch(data); })
      .finally(() => setLoading(false));
  }, [initialMatch.id]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Back bar */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '12px 16px', background: 'var(--card)',
        borderBottom: '1px solid var(--divider)', flexShrink: 0,
      }}>
        <button onClick={onBack} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          color: 'var(--text)', display: 'flex', alignItems: 'center',
          padding: '4px 0', borderRadius: 8,
        }}>
          <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <span style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)' }}>Maç Detayı</span>
        {loading && (
          <div style={{ marginLeft: 'auto', width: 18, height: 18, borderRadius: '50%', border: '2px solid var(--divider)', borderTopColor: 'var(--primary)', animation: 'spin 0.8s linear infinite' }} />
        )}
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>

      <div className="scroll-area" style={{ padding: '12px 16px' }}>
        {/* Score header */}
        <div className="card" style={{ padding: '20px 16px', marginBottom: 12 }}>
          <div style={{ textAlign: 'center', fontSize: 11, fontWeight: 500, color: 'var(--text-tertiary)', marginBottom: 16 }}>
            {match.competition}{match.round ? ` · ${match.round.replace('Regular Season - ', 'Hf.')}` : ''}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
              <TeamLogo logoUrl={match.homeTeam.logoUrl} fallback={match.homeTeam.shortName} size={56} />
              <span style={{ fontSize: 13.5, fontWeight: 600, textAlign: 'center', lineHeight: 1.3 }}>{match.homeTeam.name}</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, flexShrink: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <span style={{ fontSize: 38, fontWeight: 700, color: 'var(--text)' }}>{match.homeScore}</span>
                <div style={{ width: 1, height: 32, background: 'var(--divider)', margin: '0 10px' }} />
                <span style={{ fontSize: 38, fontWeight: 700, color: 'var(--text)' }}>{match.awayScore}</span>
              </div>
              <LiveBadge status={match.status} minute={match.minute} />
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
              <TeamLogo logoUrl={match.awayTeam.logoUrl} fallback={match.awayTeam.shortName} size={56} />
              <span style={{ fontSize: 13.5, fontWeight: 600, textAlign: 'center', lineHeight: 1.3 }}>{match.awayTeam.name}</span>
            </div>
          </div>
        </div>

        {/* Info bar */}
        <div className="card" style={{ padding: '10px 16px', marginBottom: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-evenly', alignItems: 'center' }}>
            <InfoItem icon="🏟️" label={match.stadium ?? 'Stadyum'} />
            <div style={{ width: 1, height: 32, background: 'var(--divider)' }} />
            <InfoItem icon="🟡" label={match.referee ?? 'Hakem'} />
            <div style={{ width: 1, height: 32, background: 'var(--divider)' }} />
            <InfoItem icon="⏱️" label={statusLabel(match)} />
          </div>
        </div>

        {/* Events */}
        <SectionHeader title="Olaylar" icon={<span style={{ fontSize: 15 }}>📋</span>} />
        <div className="card" style={{ padding: '16px' }}>
          <EventTimeline match={match} />
        </div>

        {/* Lineup */}
        {(match.homeStartingXI.length > 0 || match.awayStartingXI.length > 0) && (
          <>
            <SectionHeader title="İlk 11" icon={<span style={{ fontSize: 15 }}>👥</span>} />
            <div className="card" style={{ padding: '12px 0' }}>
              <LineupView
                homeTeam={match.homeTeam.name}
                awayTeam={match.awayTeam.name}
                homePlayers={match.homeStartingXI}
                awayPlayers={match.awayStartingXI}
              />
            </div>
          </>
        )}

        {/* Bench */}
        {(match.homeBench.length > 0 || match.awayBench.length > 0) && (
          <>
            <SectionHeader title="Yedekler" icon={<span style={{ fontSize: 15 }}>🪑</span>} />
            <div className="card" style={{ padding: '12px 0' }}>
              <LineupView
                homeTeam={match.homeTeam.name}
                awayTeam={match.awayTeam.name}
                homePlayers={match.homeBench}
                awayPlayers={match.awayBench}
              />
            </div>
          </>
        )}

        <div style={{ height: 24 }} />
      </div>
    </div>
  );
}

function InfoItem({ icon, label }: { icon: string; label: string }) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
      <span style={{ fontSize: 16 }}>{icon}</span>
      <span style={{ fontSize: 10.5, fontWeight: 500, color: 'var(--text-secondary)', textAlign: 'center', lineHeight: 1.3, maxWidth: 90 }}>
        {label}
      </span>
    </div>
  );
}

function statusLabel(match: Match): string {
  switch (match.status) {
    case 'live': return `Canlı ${match.minute}'`;
    case 'halftime': return 'Devre Arası';
    case 'finished': return 'Maç Bitti';
    case 'postponed': return 'Ertelendi';
    default: return 'Bekliyor';
  }
}
