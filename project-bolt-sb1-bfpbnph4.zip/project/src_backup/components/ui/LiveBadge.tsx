import type { MatchStatus } from '../../types';

interface LiveBadgeProps {
  status: MatchStatus;
  minute: number;
}

export function LiveBadge({ status, minute }: LiveBadgeProps) {
  if (status === 'live') {
    return (
      <span className="live-badge live-badge--live">
        <span className="live-dot" style={{ width: 6, height: 6 }} />
        LIVE {minute}'
      </span>
    );
  }
  if (status === 'halftime') {
    return <span className="live-badge live-badge--ht">DEVRE ARASI</span>;
  }
  if (status === 'finished') {
    return <span className="live-badge live-badge--ft">BİTTİ</span>;
  }
  if (status === 'postponed') {
    return <span className="live-badge live-badge--ft">ERTELENDİ</span>;
  }
  return <span className="live-badge live-badge--ft">BEKL.</span>;
}
