interface TeamLogoProps {
  logoUrl?: string;
  fallback: string;
  size?: number;
}

export function TeamLogo({ logoUrl, fallback, size = 48 }: TeamLogoProps) {
  const initials = fallback.length > 3 ? fallback.slice(0, 3) : fallback;

  return (
    <div
      className="team-logo"
      style={{ width: size, height: size, borderRadius: size * 0.22, flexShrink: 0 }}
    >
      {logoUrl ? (
        <img
          src={logoUrl}
          alt={fallback}
          onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
        />
      ) : (
        <span className="team-logo__fallback" style={{ fontSize: size * 0.28 }}>
          {initials}
        </span>
      )}
    </div>
  );
}
