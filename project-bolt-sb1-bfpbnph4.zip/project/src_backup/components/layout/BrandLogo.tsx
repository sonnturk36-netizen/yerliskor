interface BrandLogoProps {
  size?: number;
}

export function BrandLogo({ size = 36 }: BrandLogoProps) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <div style={{
        width: size,
        height: size,
        background: 'var(--primary)',
        borderRadius: size * 0.28,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: '0 2px 8px rgba(213,0,0,0.3)',
        flexShrink: 0,
      }}>
        <svg width={size * 0.55} height={size * 0.55} viewBox="0 0 24 24" fill="white">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15.5v-3.5l-3-1v-3l3 1V7.5l2-.5 2 .5v3l3-1v3l-3 1v3.5l-2 .5-2-.5z"/>
        </svg>
      </div>
      <span style={{ fontSize: size * 0.61, fontWeight: 700, letterSpacing: -0.3, lineHeight: 1 }}>
        <span style={{ color: 'var(--text)' }}>Yerli</span>
        <span style={{ color: 'var(--primary)' }}>Skor</span>
      </span>
    </div>
  );
}
