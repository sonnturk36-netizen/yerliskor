import { create } from 'zustand';
import type { Match } from '../types';

interface MatchStore {
  matches: Match[];
  loading: boolean;
  error: string | null;
  lastUpdated: Date | null;
  setMatches: (matches: Match[]) => void;
  setLoading: (v: boolean) => void;
  setError: (e: string | null) => void;
  updateMatch: (updated: Match) => void;
}

export const useMatchStore = create<MatchStore>((set) => ({
  matches: [],
  loading: false,
  error: null,
  lastUpdated: null,

  setMatches(matches) {
    set({ matches, loading: false, error: null, lastUpdated: new Date() });
  },

  setLoading(loading) {
    set({ loading });
  },

  setError(error) {
    set({ error, loading: false });
  },

  updateMatch(updated) {
    set(s => ({
      matches: s.matches.map(m => m.id === updated.id ? updated : m),
    }));
  },
}));
