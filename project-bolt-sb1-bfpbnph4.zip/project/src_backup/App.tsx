import { useState, useEffect } from 'react';
import { useMatchStore } from './store/matches';
import { useNotificationStore } from './store/notifications';
import { useMatchPolling } from './hooks/useMatchPolling';
import { AppBar } from './components/layout/AppBar';
import { BottomNav } from './components/layout/BottomNav';
import { MatchesScreen } from './components/matches/MatchesScreen';
import { MatchDetailsScreen } from './components/match-details/MatchDetailsScreen';
import { NotificationsScreen } from './components/notifications/NotificationsScreen';
import type { Match } from './types';

type Tab = 'matches' | 'notifications';

// Splash screen
function SplashScreen({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 1800);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'var(--bg)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      gap: 20, zIndex: 100,
    }}
    className="animate-fade-in"
    >
      <div className="animate-scale-in" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20 }}>
        <div style={{
          width: 80, height: 80,
          background: 'var(--primary)',
          borderRadius: 24,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 6px 24px rgba(213,0,0,0.35)',
        }}>
          <svg width={46} height={46} viewBox="0 0 24 24" fill="white">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15.5v-3.5l-3-1v-3l3 1V7.5l2-.5 2 .5v3l3-1v3l-3 1v3.5l-2 .5-2-.5z"/>
          </svg>
        </div>
        <div>
          <div style={{ fontSize: 34, fontWeight: 700, textAlign: 'center', letterSpacing: -0.5 }}>
            <span style={{ color: 'var(--text)' }}>Yerli</span>
            <span style={{ color: 'var(--primary)' }}>Skor</span>
          </div>
          <div style={{ fontSize: 13, color: 'var(--text-secondary)', textAlign: 'center', marginTop: 6 }}>
            Türk Futbolunun Skor Uygulaması
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [splash, setSplash] = useState(true);
  const [tab, setTab] = useState<Tab>('matches');
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);

  const matches = useMatchStore(s => s.matches);
  const unreadCount = useNotificationStore(s => s.unreadCount());

  useMatchPolling();

  const liveCount = matches.filter(m => m.status === 'live' || m.status === 'halftime').length;

  if (splash) {
    return <SplashScreen onDone={() => setSplash(false)} />;
  }

  if (selectedMatch) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100dvh' }}>
        <MatchDetailsScreen
          match={selectedMatch}
          onBack={() => setSelectedMatch(null)}
        />
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100dvh' }}>
      <AppBar liveCount={liveCount} />
      <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: tab === 'matches' ? 'flex' : 'none', flex: 1, flexDirection: 'column', overflow: 'hidden' }}>
          <MatchesScreen onMatchClick={setSelectedMatch} />
        </div>
        <div style={{ display: tab === 'notifications' ? 'flex' : 'none', flex: 1, flexDirection: 'column', overflow: 'hidden' }}>
          <NotificationsScreen />
        </div>
      </div>
      <BottomNav activeTab={tab} onTabChange={setTab} unreadCount={unreadCount} />
    </div>
  );
}
