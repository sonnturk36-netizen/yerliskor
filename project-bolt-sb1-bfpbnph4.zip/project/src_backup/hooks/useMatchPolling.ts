import { useEffect, useRef, useCallback } from 'react';
import { useMatchStore } from '../store/matches';
import { useNotificationStore } from '../store/notifications';
import { fetchTodayMatches, fetchLiveMatches } from '../services/apiFootball';
import { getPlaceholderMatches } from '../services/placeholder';
import { isApiKeyConfigured, POLL_INTERVAL_MS } from '../services/config';
import type { Match } from '../types';

export function useMatchPolling() {
  const { matches, setMatches, setLoading, setError } = useMatchStore();
  const addNotification = useNotificationStore(s => s.addNotification);
  const prevSnapshotRef = useRef<Map<string, Match>>(new Map());
  const isFirstLoad = useRef(true);

  const detectChanges = useCallback((liveMatches: Match[]) => {
    if (isFirstLoad.current) {
      isFirstLoad.current = false;
      liveMatches.forEach(m => prevSnapshotRef.current.set(m.id, m));
      return;
    }

    for (const match of liveMatches) {
      const prev = prevSnapshotRef.current.get(match.id);

      if (!prev) {
        if (match.status === 'live') {
          addNotification('matchStarted', '🔴 Maç Başladı',
            `${match.homeTeam.name} - ${match.awayTeam.name}`, match.id);
        }
      } else {
        // Status transitions
        if (prev.status !== match.status) {
          if (prev.status === 'live' && match.status === 'halftime') {
            addNotification('halfTime', '⏸ Devre Arası',
              `${match.homeTeam.name} ${match.homeScore}-${match.awayScore} ${match.awayTeam.name}`, match.id);
          } else if (prev.status === 'halftime' && match.status === 'live') {
            addNotification('secondHalfStarted', '▶ İkinci Yarı Başladı',
              `${match.homeTeam.name} ${match.homeScore}-${match.awayScore} ${match.awayTeam.name}`, match.id);
          } else if ((prev.status === 'live' || prev.status === 'halftime') && match.status === 'finished') {
            addNotification('fullTime', '🏁 Maç Bitti',
              `${match.homeTeam.name} ${match.homeScore}-${match.awayScore} ${match.awayTeam.name}`, match.id);
          }
        }

        // Goals
        if (match.homeScore > prev.homeScore) {
          const scorer = match.events.filter(e => e.type === 'goal' && e.teamId === match.homeTeam.id).pop();
          addNotification('goal', '⚽ GOOOL!',
            `${match.homeTeam.name} ${match.homeScore}-${match.awayScore} ${match.awayTeam.name}\n${scorer?.playerName ?? ''} ${match.minute}'`,
            match.id);
        }
        if (match.awayScore > prev.awayScore) {
          const scorer = match.events.filter(e => e.type === 'goal' && e.teamId === match.awayTeam.id).pop();
          addNotification('goal', '⚽ GOOOL!',
            `${match.homeTeam.name} ${match.homeScore}-${match.awayScore} ${match.awayTeam.name}\n${scorer?.playerName ?? ''} ${match.minute}'`,
            match.id);
        }

        // Cards (diff by event count)
        const prevEventIds = new Set(prev.events.map(e => e.id));
        for (const evt of match.events) {
          if (prevEventIds.has(evt.id)) continue;
          const team = evt.teamId === match.homeTeam.id ? match.homeTeam.name : match.awayTeam.name;
          if (evt.type === 'redCard') {
            addNotification('redCard', '🟥 Kırmızı Kart!', `${team} - ${evt.playerName} ${evt.minute}'`, match.id);
          } else if (evt.type === 'yellowCard') {
            addNotification('yellowCard', '🟨 Sarı Kart', `${team} - ${evt.playerName} ${evt.minute}'`, match.id);
          }
        }
      }

      prevSnapshotRef.current.set(match.id, match);
    }
  }, [addNotification]);

  const loadMatches = useCallback(async (isRefresh = false) => {
    if (!isRefresh) setLoading(true);
    setError(null);

    try {
      if (!isApiKeyConfigured()) {
        setMatches(getPlaceholderMatches());
        return;
      }

      const [today, live] = await Promise.all([
        fetchTodayMatches(),
        fetchLiveMatches(),
      ]);

      // Merge: use live data for matches that are live
      const liveIds = new Set(live.map(m => m.id));
      const merged = [
        ...live,
        ...today.filter(m => !liveIds.has(m.id)),
      ];

      // Sort: live first, then by kickoff time
      merged.sort((a, b) => {
        const aLive = a.status === 'live' || a.status === 'halftime';
        const bLive = b.status === 'live' || b.status === 'halftime';
        if (aLive && !bLive) return -1;
        if (!aLive && bLive) return 1;
        if (aLive && bLive) return b.minute - a.minute;
        return (a.kickoffTime ?? '').localeCompare(b.kickoffTime ?? '');
      });

      detectChanges(live);
      setMatches(merged);
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Bilinmeyen hata';
      setError(msg);
      // If we have nothing loaded yet, use placeholder data
      if (matches.length === 0) {
        setMatches(getPlaceholderMatches());
      }
    }
  }, [setLoading, setError, setMatches, detectChanges, matches.length]);

  // Initial load
  useEffect(() => {
    loadMatches();
  }, []);  // eslint-disable-line react-hooks/exhaustive-deps

  // Polling
  useEffect(() => {
    if (!isApiKeyConfigured()) return;
    const interval = setInterval(() => loadMatches(true), POLL_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [loadMatches]);

  return { refresh: () => loadMatches(true) };
}
