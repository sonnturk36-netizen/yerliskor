export type MatchStatus = 'scheduled' | 'live' | 'halftime' | 'finished' | 'postponed';

export interface Team {
  id: string;
  name: string;
  shortName: string;
  logoUrl?: string;
}

export interface Player {
  id: string;
  name: string;
  number: number;
  position: string;
  photoUrl?: string;
}

export type EventType = 'goal' | 'yellowCard' | 'redCard' | 'substitution' | 'varDecision';

export interface MatchEvent {
  id: string;
  minute: number;
  extraTime?: number;
  type: EventType;
  teamId: string;
  playerName: string;
  assistPlayerName?: string;
  replacedByPlayerName?: string;
  detail?: string;
}

export interface Match {
  id: string;
  homeTeam: Team;
  awayTeam: Team;
  homeScore: number;
  awayScore: number;
  status: MatchStatus;
  minute: number;
  referee?: string;
  stadium?: string;
  competition: string;
  leagueId: number;
  round?: string;
  kickoffTime?: string;
  events: MatchEvent[];
  homeStartingXI: Player[];
  awayStartingXI: Player[];
  homeBench: Player[];
  awayBench: Player[];
}

export type NotificationType =
  | 'goal'
  | 'matchStarted'
  | 'halfTime'
  | 'secondHalfStarted'
  | 'redCard'
  | 'yellowCard'
  | 'fullTime';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  matchId?: string;
  timestamp: string;
  read: boolean;
}
