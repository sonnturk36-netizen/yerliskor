import { BrandLogo } from './BrandLogo';

interface AppBarProps {
  liveCount: number;
}

export function AppBar({ liveCount }: AppBarProps) {
  return (
    <header className="app-bar">
      <div className="app-bar__content">
        <BrandLogo size={36} />
      </div>
      <div className={`live-banner ${liveCount > 0 ? 'live-banner--active' : 'live-banner--inactive'}`}>
        {liveCount > 0 ? (
          <>
            <span className="live-dot" />
            CANLI • {liveCount} MAÇ
          </>
        ) : (
          <>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--text-tertiary)', display: 'inline-block' }} />
            ŞU AN CANLI MAÇ YOK
          </>
        )}
      </div>
    </header>
  );
}
