import type { DateFilter } from '../../store/matches';

interface DateFilterBarProps {
  active: DateFilter;
  onChange: (f: DateFilter) => void;
}

export function DateFilterBar({ active, onChange }: DateFilterBarProps) {
  const tabs: { key: DateFilter; label: string }[] = [
    { key: 'past', label: 'Önceki' },
    { key: 'today', label: 'Bugün' },
    { key: 'future', label: 'Gelecek' },
  ];

  return (
    <div className="date-filter-bar">
      {tabs.map(t => (
        <button
          key={t.key}
          className={`date-filter-tab${active === t.key ? ' date-filter-tab--active' : ''}`}
          onClick={() => onChange(t.key)}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}
