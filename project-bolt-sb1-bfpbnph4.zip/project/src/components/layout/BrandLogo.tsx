import { useState } from 'react';

interface IconProps { size?: number; }

/** Inline SVG fallback — mirrors logo.svg exactly, renders if /logo.svg fails to load */
function InlineFallback({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" style={{ display: 'block' }}>
      <defs>
        <mask id="cm-fb" maskUnits="userSpaceOnUse">
          <rect width="200" height="200" fill="black"/>
          <circle cx="63" cy="53" r="28" fill="white"/>
          <circle cx="78" cy="47" r="23" fill="black"/>
        </mask>
      </defs>
      {/* Background */}
      <circle cx="100" cy="100" r="100" fill="#D50000"/>
      <circle cx="100" cy="100" r="94" fill="none" stroke="rgba(255,255,255,0.18)" strokeWidth="1.5"/>
      {/* Crescent */}
      <circle cx="63" cy="53" r="28" fill="white" mask="url(#cm-fb)"/>
      {/* Star */}
      <polygon points="110,31 113.06,39.79 122.36,39.98 114.95,45.61 117.64,54.52 110,49.2 102.36,54.52 105.05,45.61 97.64,39.98 106.94,39.79" fill="white"/>
      {/* Player head */}
      <circle cx="100" cy="86" r="11" fill="white"/>
      {/* Player body */}
      <g stroke="white" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <line x1="100" y1="97"  x2="102" y2="122" strokeWidth="14"/>
        <line x1="100" y1="108" x2="81"  y2="100" strokeWidth="9"/>
        <line x1="100" y1="108" x2="118" y2="118" strokeWidth="9"/>
        <line x1="99"  y1="122" x2="82"  y2="144" strokeWidth="13"/>
        <line x1="82"  y1="144" x2="81"  y2="164" strokeWidth="12"/>
        <line x1="105" y1="122" x2="127" y2="112" strokeWidth="13"/>
        <line x1="127" y1="112" x2="147" y2="126" strokeWidth="12"/>
      </g>
      {/* Football */}
      <circle cx="155" cy="133" r="13" fill="white"/>
      <polygon points="155,127 160.71,131.15 158.53,137.85 151.47,137.85 149.29,131.15" fill="#D50000" opacity="0.65"/>
    </svg>
  );
}

/** Official YerliSkor icon — loads /logo.svg with inline SVG fallback */
export function YerliSkorIcon({ size = 36 }: IconProps) {
  const [imgFailed, setImgFailed] = useState(false);

  if (imgFailed) return <InlineFallback size={size} />;

  return (
    <img
      src="/logo.svg"
      alt="YerliSkor"
      width={size}
      height={size}
      onError={() => setImgFailed(true)}
      style={{ display: 'block', width: size, height: size, objectFit: 'contain' }}
    />
  );
}

interface BrandLogoProps {
  size?: number;
  textSize?: number;
}

/** Combined brand mark: icon + "YerliSkor" text */
export function BrandLogo({ size = 36, textSize }: BrandLogoProps) {
  const fs = textSize ?? Math.round(size * 0.60);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, userSelect: 'none' }}>
      <div style={{
        width: size,
        height: size,
        borderRadius: size * 0.22,
        overflow: 'hidden',
        boxShadow: '0 2px 10px rgba(213,0,0,0.28)',
        flexShrink: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#D50000',
      }}>
        <YerliSkorIcon size={size} />
      </div>
      <span style={{ fontSize: fs, fontWeight: 700, letterSpacing: -0.3, lineHeight: 1, whiteSpace: 'nowrap' }}>
        <span style={{ color: 'var(--text)' }}>Yerli</span>
        <span style={{ color: 'var(--primary)' }}>Skor</span>
      </span>
    </div>
  );
}
