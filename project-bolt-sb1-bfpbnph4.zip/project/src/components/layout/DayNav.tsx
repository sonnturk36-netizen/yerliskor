import { useRef, useEffect } from 'react';
import { dateSectionLabel, offsetDate, todayIstanbul } from '../../services/dateUtils';
import type { DateFilter } from '../../store/matches';

interface DayNavProps {
  filter: DateFilter;
  selectedDay: string;
  onSelect: (day: string) => void;
}

function getDaysForFilter(filter: DateFilter): string[] {
  const today = todayIstanbul();
  const days: string[] = [];

  if (filter === 'past') {
    // Show last 14 days (most recent first)
    for (let i = 1; i <= 14; i++) {
      days.push(offsetDate(today, -i));
    }
  } else if (filter === 'future') {
    // Show next 14 days
    for (let i = 1; i <= 14; i++) {
      days.push(offsetDate(today, i));
    }
  } else {
    // Today only — still show yesterday/today/tomorrow for quick navigation
    days.push(offsetDate(today, -1));
    days.push(today);
    days.push(offsetDate(today, 1));
    days.push(offsetDate(today, 2));
    days.push(offsetDate(today, 3));
  }

  return days;
}

export function DayNav({ filter, selectedDay, onSelect }: DayNavProps) {
  const days = getDaysForFilter(filter);
  const containerRef = useRef<HTMLDivElement>(null);
  const activeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (activeRef.current && containerRef.current) {
      activeRef.current.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }
  }, [selectedDay]);

  return (
    <div className="day-nav" ref={containerRef}>
      {days.map(day => {
        const isActive = day === selectedDay;
        return (
          <button
            key={day}
            ref={isActive ? activeRef : undefined}
            className={`day-nav__chip${isActive ? ' day-nav__chip--active' : ''}`}
            onClick={() => onSelect(day)}
          >
            {dateSectionLabel(day)}
          </button>
        );
      })}
    </div>
  );
}
