interface BottomNavProps {
  activeTab: 'matches' | 'notifications';
  onTabChange: (tab: 'matches' | 'notifications') => void;
  unreadCount: number;
}

export function BottomNav({ activeTab, onTabChange, unreadCount }: BottomNavProps) {
  return (
    <nav className="bottom-nav">
      <button
        className={`bottom-nav__item ${activeTab === 'matches' ? 'bottom-nav__item--active' : ''}`}
        onClick={() => onTabChange('matches')}
      >
        <svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10"/>
          <path d="M12 2a10 10 0 0 1 7.07 17.07M12 2a10 10 0 0 0-7.07 17.07M9 12l2 2 4-4"/>
        </svg>
        <span className="bottom-nav__label">Maçlar</span>
      </button>

      <button
        className={`bottom-nav__item ${activeTab === 'notifications' ? 'bottom-nav__item--active' : ''}`}
        onClick={() => onTabChange('notifications')}
        style={{ position: 'relative' }}
      >
        {unreadCount > 0 && (
          <span className="badge">{unreadCount > 99 ? '99+' : unreadCount}</span>
        )}
        <svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
          {activeTab === 'notifications' ? (
            <>
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
            </>
          ) : (
            <>
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
            </>
          )}
        </svg>
        <span className="bottom-nav__label">Bildirimler</span>
      </button>
    </nav>
  );
}
