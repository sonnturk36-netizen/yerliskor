import { useNotificationStore } from '../../store/notifications';
import type { AppNotification, NotificationType } from '../../types';

export function NotificationsScreen() {
  const { notifications, markAsRead, markAllAsRead, clearAll, unreadCount } = useNotificationStore();
  const count = unreadCount();

  if (notifications.length === 0) {
    return (
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, padding: 32, textAlign: 'center' }}>
        <svg width={64} height={64} viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" strokeWidth={1.2}>
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-secondary)' }}>Henüz bildirim yok</span>
        <span style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>
          Gol, kart ve maç durum bildirimleri burada görünecek
        </span>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Top actions bar */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '8px 16px 4px',
        flexShrink: 0,
      }}>
        <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
          {count > 0 ? `${count} okunmamış` : 'Tümü okundu'}
        </span>
        <div style={{ display: 'flex', gap: 8 }}>
          {count > 0 && (
            <button onClick={markAllAsRead} style={{ background: 'none', border: 'none', fontSize: 12, fontWeight: 600, color: 'var(--primary)', cursor: 'pointer', padding: '4px 8px', fontFamily: 'Poppins' }}>
              Tümünü okundu işaretle
            </button>
          )}
          <button onClick={clearAll} style={{ background: 'none', border: 'none', fontSize: 12, fontWeight: 500, color: 'var(--text-tertiary)', cursor: 'pointer', padding: '4px 8px', fontFamily: 'Poppins' }}>
            Temizle
          </button>
        </div>
      </div>

      <div className="scroll-area" style={{ padding: '4px 16px' }}>
        {notifications.map((n, i) => (
          <NotificationItem key={n.id} notification={n} index={i} onTap={() => markAsRead(n.id)} />
        ))}
        <div style={{ height: 24 }} />
      </div>
    </div>
  );
}

function NotificationItem({ notification: n, index, onTap }: { notification: AppNotification; index: number; onTap: () => void }) {
  return (
    <div
      className="card animate-slide-in"
      style={{
        marginBottom: 10, cursor: n.read ? 'default' : 'pointer',
        animationDelay: `${index * 40}ms`,
        padding: '12px 14px',
        display: 'flex', gap: 12, alignItems: 'flex-start',
        opacity: n.read ? 0.75 : 1,
        transition: 'opacity 0.2s',
      }}
      onClick={onTap}
    >
      <div style={{
        width: 40, height: 40, borderRadius: 12, flexShrink: 0,
        background: `${notifColor(n.type)}18`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 18,
      }}>
        {notifEmoji(n.type)}
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
          {!n.read && (
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--primary)', flexShrink: 0, display: 'inline-block' }} />
          )}
          <span style={{ fontSize: 13.5, fontWeight: n.read ? 500 : 700, color: 'var(--text)' }}>
            {n.title}
          </span>
        </div>
        <div style={{ fontSize: 12.5, color: 'var(--text-secondary)', lineHeight: 1.4, whiteSpace: 'pre-line' }}>
          {n.body}
        </div>
        <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 5 }}>
          {timeAgo(n.timestamp)}
        </div>
      </div>
    </div>
  );
}

function notifEmoji(type: NotificationType): string {
  switch (type) {
    case 'goal': return '⚽';
    case 'matchStarted': return '🔴';
    case 'halfTime': return '⏸️';
    case 'secondHalfStarted': return '▶️';
    case 'redCard': return '🟥';
    case 'yellowCard': return '🟨';
    case 'fullTime': return '🏁';
  }
}

function notifColor(type: NotificationType): string {
  switch (type) {
    case 'goal': case 'matchStarted': case 'secondHalfStarted': return '#D50000';
    case 'halfTime': return '#F9A825';
    case 'redCard': return '#D50000';
    case 'yellowCard': return '#FBC02D';
    case 'fullTime': return '#6B6B6B';
  }
}

function timeAgo(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60_000);
  if (mins < 1) return 'Az önce';
  if (mins < 60) return `${mins} dakika önce`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} saat önce`;
  return `${Math.floor(hrs / 24)} gün önce`;
}
