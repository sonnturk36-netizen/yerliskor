import type { Player } from '../../types';

interface LineupViewProps {
  homeTeam: string;
  awayTeam: string;
  homePlayers: Player[];
  awayPlayers: Player[];
}

export function LineupView({ homeTeam, awayTeam, homePlayers, awayPlayers }: LineupViewProps) {
  return (
    <div style={{ display: 'flex' }}>
      <PlayerColumn teamName={homeTeam} players={homePlayers} />
      <div style={{ width: 1, background: 'var(--divider)', alignSelf: 'stretch' }} />
      <PlayerColumn teamName={awayTeam} players={awayPlayers} />
    </div>
  );
}

function PlayerColumn({ teamName, players }: { teamName: string; players: Player[] }) {
  return (
    <div style={{ flex: 1, padding: '0 12px' }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--primary)', textAlign: 'center', marginBottom: 10 }}>
        {teamName}
      </div>
      {players.map(p => (
        <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <div style={{
            width: 24, height: 24, borderRadius: 6, flexShrink: 0,
            background: 'var(--bg)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <span style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--primary)' }}>{p.number}</span>
          </div>
          <div style={{ flex: 1, overflow: 'hidden' }}>
            <div style={{ fontSize: 12.5, fontWeight: 500, color: 'var(--text)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {p.name}
            </div>
            <div style={{ fontSize: 10, color: 'var(--text-tertiary)' }}>{p.position}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
