import { useState, useEffect } from 'react';
import type { Match } from '../../types';
import { fetchMatchDetails } from '../../services/apiFootball';
import { isApiKeyConfigured } from '../../services/config';
import { TeamLogo } from '../ui/TeamLogo';
import { LiveBadge } from '../ui/LiveBadge';
import { SectionHeader } from '../ui/SectionHeader';
import { EventTimeline } from './EventTimeline';
import { LineupView } from './LineupView';

interface MatchDetailsScreenProps {
  match: Match;
  onBack: () => void;
}

const NA = 'Veri henüz açıklanmadı';

export function MatchDetailsScreen({ match: initialMatch, onBack }: MatchDetailsScreenProps) {
  const [match, setMatch] = useState<Match>(initialMatch);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isApiKeyConfigured()) return;
    setLoading(true);
    fetchMatchDetails(initialMatch.id)
      .then(data => { if (data) setMatch(data); })
      .finally(() => setLoading(false));
  }, [initialMatch.id]);

  const isStarted = match.status !== 'scheduled';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Back bar */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 12,
        padding: '12px 16px', background: 'var(--card)',
        borderBottom: '1px solid var(--divider)', flexShrink: 0,
      }}>
        <button onClick={onBack} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          color: 'var(--text)', display: 'flex', alignItems: 'center',
          padding: '4px 0', borderRadius: 8,
        }}>
          <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <span style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)' }}>Maç Detayı</span>
        {loading && (
          <div style={{ marginLeft: 'auto', width: 18, height: 18, borderRadius: '50%', border: '2px solid var(--divider)', borderTopColor: 'var(--primary)', animation: 'spin 0.8s linear infinite' }} />
        )}
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>

      <div className="scroll-area" style={{ padding: '12px 16px' }}>
        {/* Score header */}
        <div className="card" style={{ padding: '18px 14px', marginBottom: 10 }}>
          <div style={{ textAlign: 'center', fontSize: 11, fontWeight: 500, color: 'var(--text-tertiary)', marginBottom: 14 }}>
            {match.competition}
            {match.round ? ` · ${match.round.replace('Regular Season - ', 'Hf.')}` : ''}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 9 }}>
              <TeamLogo logoUrl={match.homeTeam.logoUrl} size={56} teamName={match.homeTeam.name} />
              <span style={{ fontSize: 13, fontWeight: 600, textAlign: 'center', lineHeight: 1.3 }}>
                {match.homeTeam.name}
              </span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, flexShrink: 0 }}>
              {isStarted ? (
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <span style={{ fontSize: 36, fontWeight: 700, color: 'var(--text)' }}>
                    {match.homeScore ?? 0}
                  </span>
                  <div style={{ width: 1, height: 30, background: 'var(--divider)', margin: '0 10px' }} />
                  <span style={{ fontSize: 36, fontWeight: 700, color: 'var(--text)' }}>
                    {match.awayScore ?? 0}
                  </span>
                </div>
              ) : (
                <span style={{ fontSize: 28, fontWeight: 700, color: 'var(--text-tertiary)' }}>—</span>
              )}
              <LiveBadge match={match} />
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 9 }}>
              <TeamLogo logoUrl={match.awayTeam.logoUrl} size={56} teamName={match.awayTeam.name} />
              <span style={{ fontSize: 13, fontWeight: 600, textAlign: 'center', lineHeight: 1.3 }}>
                {match.awayTeam.name}
              </span>
            </div>
          </div>
        </div>

        {/* Info bar */}
        <div className="card" style={{ padding: '10px 14px', marginBottom: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-evenly', alignItems: 'center' }}>
            <InfoItem
              icon="🏟️"
              label={match.stadium ?? NA}
              empty={!match.stadium}
            />
            <div style={{ width: 1, height: 32, background: 'var(--divider)' }} />
            <InfoItem
              icon="🟡"
              label={match.referee ?? NA}
              empty={!match.referee}
            />
            <div style={{ width: 1, height: 32, background: 'var(--divider)' }} />
            <InfoItem icon="⏱️" label={detailStatusLabel(match)} />
          </div>
        </div>

        {/* Events */}
        <SectionHeader title="Olaylar" icon={<span style={{ fontSize: 15 }}>📋</span>} />
        <div className="card" style={{ padding: '14px' }}>
          <EventTimeline match={match} />
        </div>

        {/* Lineup */}
        {(match.homeStartingXI.length > 0 || match.awayStartingXI.length > 0) ? (
          <>
            <SectionHeader title="İlk 11" icon={<span style={{ fontSize: 15 }}>👥</span>} />
            <div className="card" style={{ padding: '12px 0' }}>
              <LineupView
                homeTeam={match.homeTeam.name}
                awayTeam={match.awayTeam.name}
                homePlayers={match.homeStartingXI}
                awayPlayers={match.awayStartingXI}
              />
            </div>
          </>
        ) : (
          isStarted && (
            <>
              <SectionHeader title="İlk 11" icon={<span style={{ fontSize: 15 }}>👥</span>} />
              <EmptySection message={NA} />
            </>
          )
        )}

        {/* Bench */}
        {(match.homeBench.length > 0 || match.awayBench.length > 0) ? (
          <>
            <SectionHeader title="Yedekler" icon={<span style={{ fontSize: 15 }}>🪑</span>} />
            <div className="card" style={{ padding: '12px 0' }}>
              <LineupView
                homeTeam={match.homeTeam.name}
                awayTeam={match.awayTeam.name}
                homePlayers={match.homeBench}
                awayPlayers={match.awayBench}
              />
            </div>
          </>
        ) : null}

        <div style={{ height: 24 }} />
      </div>
    </div>
  );
}

function InfoItem({ icon, label, empty }: { icon: string; label: string; empty?: boolean }) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
      <span style={{ fontSize: 16 }}>{icon}</span>
      <span style={{
        fontSize: 10, fontWeight: 500,
        color: empty ? 'var(--text-tertiary)' : 'var(--text-secondary)',
        textAlign: 'center', lineHeight: 1.3, maxWidth: 90,
        fontStyle: empty ? 'italic' : 'normal',
      }}>
        {label}
      </span>
    </div>
  );
}

function EmptySection({ message }: { message: string }) {
  return (
    <div className="card" style={{ padding: '16px', textAlign: 'center' }}>
      <span style={{ fontSize: 12.5, color: 'var(--text-tertiary)', fontStyle: 'italic' }}>{message}</span>
    </div>
  );
}

function detailStatusLabel(match: Match): string {
  const { statusShort, minute, extraTimeMinute } = match;
  switch (statusShort) {
    case 'NS': return 'Henüz Başlamadı';
    case '1H': return `1. Yarı • ${minute}${extraTimeMinute ? '+' + extraTimeMinute : ''}'`;
    case 'HT': return 'Devre Arası';
    case '2H': return `2. Yarı • ${minute}${extraTimeMinute ? '+' + extraTimeMinute : ''}'`;
    case 'ET': return `Uzatmalar • ${minute}'`;
    case 'BT': return 'Uzatma Arası';
    case 'P': return 'Penaltılar';
    case 'FT': return 'Maç Bitti';
    case 'AET': return 'Uzatmada Bitti';
    case 'PEN': return 'Penaltıda Bitti';
    case 'PST': return 'Ertelendi';
    case 'CANC': return 'İptal Edildi';
    case 'ABD': return 'Yarıda Bırakıldı';
    case 'SUSP': case 'INT': return 'Durduruldu';
    case 'AWD': case 'WO': return 'Hükmen';
    default: return match.status === 'live' ? `${minute}'` : 'Bilinmiyor';
  }
}
