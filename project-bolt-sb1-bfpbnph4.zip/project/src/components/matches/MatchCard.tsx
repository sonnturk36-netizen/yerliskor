import type { Match } from '../../types';
import { TeamLogo } from '../ui/TeamLogo';
import { LiveBadge } from '../ui/LiveBadge';
import { formatTime, formatShortDate, toIstanbulDate, todayIstanbul } from '../../services/dateUtils';

interface MatchCardProps {
  match: Match;
  onClick: () => void;
  index?: number;
  /** When true, show the date inside the card (for multi-date views) */
  showDate?: boolean;
}

export function MatchCard({ match, onClick, index = 0, showDate = false }: MatchCardProps) {
  const isScheduled = match.status === 'scheduled';
  const homeScore = match.homeScore;
  const awayScore = match.awayScore;

  const kickoffLabel = match.kickoffTime
    ? (() => {
        const dateKey = toIstanbulDate(match.kickoffTime);
        const today = todayIstanbul();
        const prefix = showDate && dateKey !== today ? `${formatShortDate(match.kickoffTime)} ` : '';
        return `${prefix}${formatTime(match.kickoffTime)}`;
      })()
    : '';

  return (
    <div
      className="card animate-slide-in"
      style={{
        marginBottom: 10,
        cursor: 'pointer',
        animationDelay: `${index * 50}ms`,
        WebkitTapHighlightColor: 'transparent',
      }}
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={e => e.key === 'Enter' && onClick()}
    >
      <div style={{ padding: '12px 14px' }}>
        {/* Status row */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', marginBottom: 10 }}>
          <LiveBadge match={match} />
        </div>

        {/* Teams and score */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {/* Home team */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 7 }}>
            <TeamLogo logoUrl={match.homeTeam.logoUrl} size={44} teamName={match.homeTeam.name} />
            <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', textAlign: 'center', lineHeight: 1.3 }}>
              {match.homeTeam.name}
            </span>
          </div>

          {/* Score / separator */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            flexDirection: 'column',
            gap: 6,
            minWidth: 68,
            flexShrink: 0,
          }}>
            {isScheduled ? (
              <>
                {/* Upcoming: show dash + kickoff time */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-tertiary)' }}>—</span>
                </div>
                {kickoffLabel ? (
                  <span style={{ fontSize: 11.5, fontWeight: 600, color: 'var(--primary)', letterSpacing: 0.2 }}>
                    {kickoffLabel}
                  </span>
                ) : null}
              </>
            ) : (
              <div style={{
                background: 'var(--bg)',
                borderRadius: 10,
                padding: '7px 10px',
                display: 'flex',
                alignItems: 'center',
              }}>
                <span style={{ fontSize: 26, fontWeight: 700, color: 'var(--text)', lineHeight: 1 }}>
                  {homeScore ?? 0}
                </span>
                <div style={{ width: 1, height: 22, background: 'var(--divider)', margin: '0 7px' }} />
                <span style={{ fontSize: 26, fontWeight: 700, color: 'var(--text)', lineHeight: 1 }}>
                  {awayScore ?? 0}
                </span>
              </div>
            )}
          </div>

          {/* Away team */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 7 }}>
            <TeamLogo logoUrl={match.awayTeam.logoUrl} size={44} teamName={match.awayTeam.name} />
            <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', textAlign: 'center', lineHeight: 1.3 }}>
              {match.awayTeam.name}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
