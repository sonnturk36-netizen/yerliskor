import { useEffect, useCallback } from 'react';
import { useMatchStore, type DateFilter } from '../../store/matches';
import { useMatchPolling } from '../../hooks/useMatchPolling';
import { isApiKeyConfigured, LEAGUE_ORDER, leagueAccent, leagueEmoji, TURKISH_LEAGUE_IDS } from '../../services/config';
import { fetchPastMatches, fetchFutureMatches, fetchTodayMatches } from '../../services/apiFootball';
import { getPlaceholderMatches } from '../../services/placeholder';
import { toIstanbulDate, todayIstanbul } from '../../services/dateUtils';
import { DateFilterBar } from '../layout/DateFilterBar';
import { DayNav } from '../layout/DayNav';
import { MatchCard } from './MatchCard';
import type { Match } from '../../types';

const LEAGUE_LABELS: Record<number, string> = {
  203: 'Trendyol Süper Lig',
  204: 'Trendyol 1. Lig',
  205: 'TFF 2. Lig',
  206: 'TFF 3. Lig',
  207: 'Ziraat Türkiye Kupası',
};

function isMatchLive(m: Match) {
  return m.status === 'live' || m.status === 'halftime';
}

function sortByPriority(matches: Match[]): Match[] {
  return [...matches].sort((a, b) => {
    const pa = isMatchLive(a) ? 0 : a.status === 'scheduled' ? 1 : 2;
    const pb = isMatchLive(b) ? 0 : b.status === 'scheduled' ? 1 : 2;
    if (pa !== pb) return pa - pb;
    if (pa === 0) return b.minute - a.minute;
    return (a.kickoffTime ?? '').localeCompare(b.kickoffTime ?? '');
  });
}

function groupByLeague(matches: Match[]): Map<number, Match[]> {
  const map = new Map<number, Match[]>();
  for (const m of matches) {
    const lid = TURKISH_LEAGUE_IDS.includes(m.leagueId) ? m.leagueId : 0;
    if (!map.has(lid)) map.set(lid, []);
    map.get(lid)!.push(m);
  }
  return new Map(
    [...map.entries()]
      .sort(([a], [b]) => (LEAGUE_ORDER[a] ?? 99) - (LEAGUE_ORDER[b] ?? 99))
  );
}

function filterByDay(matches: Match[], day: string): Match[] {
  return matches.filter(m =>
    m.kickoffTime ? toIstanbulDate(m.kickoffTime) === day : false
  );
}

interface Props {
  onMatchClick: (m: Match) => void;
}

export function MatchesScreen({ onMatchClick }: Props) {
  const {
    matches, loading, error,
    pastMatches, pastLoading, pastLoadedDays,
    futureMatches, futureLoading, futureLoadedDays,
    dateFilter, selectedDay,
    setDateFilter, setSelectedDay,
    setPastMatches, setPastLoading, setPastLoadedDays,
    setFutureMatches, setFutureLoading, setFutureLoadedDays,
    appendPastMatches, appendFutureMatches,
  } = useMatchStore();

  const { refresh } = useMatchPolling();
  const noApiKey = !isApiKeyConfigured();
  const today = todayIstanbul();

  // Load past matches when tab first selected
  const loadPast = useCallback(async (days: number) => {
    setPastLoading(true);
    try {
      if (!noApiKey) {
        const m = await fetchPastMatches(days);
        if (days <= 7) setPastMatches(m);
        else appendPastMatches(m.slice((days - 7) * 3)); // approximate
        setPastLoadedDays(days);
      } else {
        setPastMatches(getPlaceholderMatches().filter(m => m.status === 'finished'));
        setPastLoadedDays(7);
      }
    } catch { /* keep previous */ }
    finally { setPastLoading(false); }
  }, [noApiKey, setPastLoading, setPastMatches, setPastLoadedDays, appendPastMatches]);

  const loadFuture = useCallback(async (days: number) => {
    setFutureLoading(true);
    try {
      if (!noApiKey) {
        const m = await fetchFutureMatches(days);
        if (days <= 7) setFutureMatches(m);
        else appendFutureMatches(m.slice((days - 7) * 3));
        setFutureLoadedDays(days);
      } else {
        setFutureMatches(getPlaceholderMatches().filter(m => m.status === 'scheduled'));
        setFutureLoadedDays(7);
      }
    } catch { /* keep previous */ }
    finally { setFutureLoading(false); }
  }, [noApiKey, setFutureLoading, setFutureMatches, setFutureLoadedDays, appendFutureMatches]);

  // Auto-load when filter changes
  useEffect(() => {
    if (dateFilter === 'past' && pastLoadedDays === 0) loadPast(7);
    if (dateFilter === 'future' && futureLoadedDays === 0) loadFuture(7);
  }, [dateFilter]); // eslint-disable-line react-hooks/exhaustive-deps

  // Handle filter change — reload today matches if switching back
  const handleFilterChange = useCallback((f: DateFilter) => {
    setDateFilter(f);
    if (f === 'today') refresh();
  }, [setDateFilter, refresh]);

  // Decide which matches to show
  let activeMatches: Match[] = [];
  let activeLoading = false;

  if (dateFilter === 'today') {
    activeMatches = filterByDay(matches, selectedDay);
    activeLoading = loading;
    // If selected day is not today, need to fetch that day
  } else if (dateFilter === 'past') {
    activeMatches = filterByDay(pastMatches, selectedDay);
    activeLoading = pastLoading;
  } else {
    activeMatches = filterByDay(futureMatches, selectedDay);
    activeLoading = futureLoading;
  }

  // For today filter + non-today day selected, fetch on the fly
  useEffect(() => {
    if (dateFilter !== 'today') return;
    if (selectedDay === today) return;
    // Fetch that specific day
    setDateFilter('today'); // keeps filter on today tab but shows a past/future day
    if (!noApiKey) {
      const dateObj = new Date(selectedDay + 'T12:00:00Z');
      fetchTodayMatches(dateObj).then(m => {
        // merge into matches without replacing today's data
        useMatchStore.getState().setMatches([
          ...useMatchStore.getState().matches.filter(x =>
            x.kickoffTime ? toIstanbulDate(x.kickoffTime) !== selectedDay : true
          ),
          ...m,
        ]);
      });
    }
  }, [selectedDay]); // eslint-disable-line react-hooks/exhaustive-deps

  const grouped = groupByLeague(sortByPriority(activeMatches));
  const liveCount = matches.filter(m =>
    m.statusShort === '1H' || m.statusShort === '2H' ||
    m.statusShort === 'ET' || m.statusShort === 'P'
  ).length;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      {/* Date filter tabs */}
      <DateFilterBar active={dateFilter} onChange={handleFilterChange} />
      {/* Day chip navigation */}
      <DayNav filter={dateFilter} selectedDay={selectedDay} onSelect={setSelectedDay} />

      {/* Main scroll area */}
      <div className="scroll-area" style={{ padding: '0 14px' }}>
        {/* Demo banner */}
        {noApiKey && (
          <div style={{
            background: 'rgba(249,168,37,0.10)', border: '1px solid rgba(249,168,37,0.3)',
            borderRadius: 12, padding: '9px 13px', margin: '10px 0',
            display: 'flex', alignItems: 'flex-start', gap: 10,
          }}>
            <span style={{ fontSize: 17, lineHeight: 1.4 }}>🔑</span>
            <div>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: '#b07800' }}>Demo Modu — Gerçek veri değil</div>
              <div style={{ fontSize: 11.5, color: 'var(--text-secondary)', marginTop: 2, lineHeight: 1.4 }}>
                Gerçek verileri görmek için .env dosyasına <code>VITE_API_FOOTBALL_KEY</code> ekleyin.
              </div>
            </div>
          </div>
        )}

        {/* Live counter badge (only on today tab) */}
        {dateFilter === 'today' && liveCount > 0 && (
          <div style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '6px 10px', marginBottom: 4,
            fontSize: 12, fontWeight: 700, color: 'var(--primary)',
          }}>
            <span className="live-dot" />
            {liveCount} CANLI MAÇ
          </div>
        )}

        {/* Loading spinner */}
        {activeLoading && activeMatches.length === 0 && <LoadingSpinner />}

        {/* Error */}
        {error && activeMatches.length === 0 && !activeLoading && (
          <ErrorView message={error} onRetry={refresh} />
        )}

        {/* Empty state */}
        {!activeLoading && activeMatches.length === 0 && !error && (
          <EmptyState filter={dateFilter} />
        )}

        {/* Competition groups */}
        {[...grouped.entries()].map(([leagueId, leagueMatches]) => (
          <CompetitionGroup
            key={leagueId}
            leagueId={leagueId}
            matches={leagueMatches}
            onMatchClick={onMatchClick}
          />
        ))}

        {/* Load more */}
        {dateFilter === 'past' && pastMatches.length > 0 && (
          <LoadMoreButton
            loading={pastLoading}
            onClick={() => loadPast(pastLoadedDays + 7)}
            label="Daha Fazla Önceki Maç"
          />
        )}
        {dateFilter === 'future' && futureMatches.length > 0 && (
          <LoadMoreButton
            loading={futureLoading}
            onClick={() => loadFuture(futureLoadedDays + 7)}
            label="Daha Fazla Sonraki Maç"
          />
        )}

        <div style={{ height: 24 }} />
      </div>
    </div>
  );
}

// ── Sub-components ──

function CompetitionGroup({ leagueId, matches, onMatchClick }: {
  leagueId: number; matches: Match[]; onMatchClick: (m: Match) => void;
}) {
  const accent = leagueAccent(leagueId);
  const emoji = leagueEmoji(leagueId);
  const label = LEAGUE_LABELS[leagueId] ?? `Lig ${leagueId}`;
  const hasLive = matches.some(isMatchLive);

  return (
    <div style={{ marginBottom: 4 }}>
      {/* Competition heading */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '13px 2px 8px',
      }}>
        <div style={{ width: 4, height: 18, background: accent, borderRadius: 2, flexShrink: 0 }} />
        <span style={{ fontSize: 12, marginRight: -2 }}>{emoji}</span>
        <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--text)', flex: 1 }}>
          {label}
        </span>
        {hasLive && (
          <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, fontWeight: 700, color: 'var(--primary)' }}>
            <span className="live-dot" style={{ width: 6, height: 6 }} />
            CANLI
          </span>
        )}
      </div>

      {matches.map((m, i) => (
        <MatchCard key={m.id} match={m} onClick={() => onMatchClick(m)} index={i} />
      ))}
    </div>
  );
}

function LoadingSpinner() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 12, padding: '40px 0' }}>
      <div style={{ width: 36, height: 36, borderRadius: '50%', border: '3px solid var(--divider)', borderTopColor: 'var(--primary)', animation: 'spin 0.8s linear infinite' }} />
      <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>Maçlar yükleniyor...</span>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function ErrorView({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, padding: '40px 20px', textAlign: 'center' }}>
      <svg width={44} height={44} viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" strokeWidth={1.5}>
        <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
      </svg>
      <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-secondary)' }}>Yüklenemedi</span>
      <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{message}</span>
      <button onClick={onRetry} style={{ background: 'var(--primary)', color: '#fff', border: 'none', borderRadius: 10, padding: '9px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'Poppins' }}>
        Tekrar Dene
      </button>
    </div>
  );
}

function EmptyState({ filter }: { filter: DateFilter }) {
  const msg = filter === 'past' ? 'Bu tarihte tamamlanan maç yok'
    : filter === 'future' ? 'Bu tarihte planlanan maç yok'
    : 'Bugün maç bulunmuyor';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, marginTop: 60, textAlign: 'center', padding: '0 20px' }}>
      <svg width={58} height={58} viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" strokeWidth={1.2}>
        <circle cx="12" cy="12" r="10"/>
        <polyline points="12 6 12 12 16 14"/>
      </svg>
      <span style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-secondary)' }}>{msg}</span>
    </div>
  );
}

function LoadMoreButton({ loading, onClick, label }: { loading: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      disabled={loading}
      style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        width: '100%', padding: '12px', background: 'var(--card)',
        border: '1.5px solid var(--divider)', borderRadius: 12,
        fontSize: 13, fontWeight: 600, color: loading ? 'var(--text-tertiary)' : 'var(--primary)',
        cursor: loading ? 'not-allowed' : 'pointer', fontFamily: 'Poppins',
        marginBottom: 10,
      }}
    >
      {loading ? (
        <><span style={{ width: 14, height: 14, borderRadius: '50%', border: '2px solid var(--divider)', borderTopColor: 'var(--primary)', animation: 'spin 0.7s linear infinite', display: 'inline-block' }} /> Yükleniyor...</>
      ) : label}
    </button>
  );
}
