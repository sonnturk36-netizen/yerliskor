import type { ReactNode } from 'react';

interface SectionHeaderProps {
  title: string;
  icon?: ReactNode;
  color?: string;
}

export function SectionHeader({ title, icon, color }: SectionHeaderProps) {
  return (
    <div className="section-header">
      <div className="section-header__bar" style={color ? { background: color } : undefined} />
      {icon && <span style={{ color: color ?? 'var(--primary)', display: 'flex' }}>{icon}</span>}
      <span className="section-header__title">{title}</span>
    </div>
  );
}
