import { useState } from 'react';

interface TeamLogoProps {
  logoUrl?: string;
  size?: number;
  teamName?: string;
}

function FootballFallback({ size }: { size: number }) {
  const r = size * 0.36;
  return (
    <svg
      width={size * 0.68}
      height={size * 0.68}
      viewBox="0 0 24 24"
      fill="none"
      style={{ opacity: 0.35 }}
    >
      <circle cx="12" cy="12" r="10" stroke="#9E9E9E" strokeWidth="1.5"/>
      <polygon points="12,7 14.5,9.5 13.5,12.5 10.5,12.5 9.5,9.5" fill="#9E9E9E"/>
      <line x1="12" y1="7" x2="12" y2="3.5" stroke="#9E9E9E" strokeWidth="1"/>
      <line x1="14.5" y1="9.5" x2="17.5" y2="8" stroke="#9E9E9E" strokeWidth="1"/>
      <line x1="13.5" y1="12.5" x2="16" y2="14.5" stroke="#9E9E9E" strokeWidth="1"/>
      <line x1="10.5" y1="12.5" x2="8" y2="14.5" stroke="#9E9E9E" strokeWidth="1"/>
      <line x1="9.5" y1="9.5" x2="6.5" y2="8" stroke="#9E9E9E" strokeWidth="1"/>
      {/* suppress unused variable warning */}
      <title>r={r}</title>
    </svg>
  );
}

export function TeamLogo({ logoUrl, size = 44, teamName }: TeamLogoProps) {
  const [imgFailed, setImgFailed] = useState(false);
  const showLogo = logoUrl && !imgFailed;

  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.22,
        border: '1px solid var(--divider)',
        background: 'var(--bg)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
        flexShrink: 0,
      }}
    >
      {showLogo ? (
        <img
          src={logoUrl}
          alt={teamName ?? ''}
          width={size}
          height={size}
          onError={() => setImgFailed(true)}
          style={{
            width: size - 6,
            height: size - 6,
            objectFit: 'contain',
            display: 'block',
          }}
        />
      ) : (
        <FootballFallback size={size} />
      )}
    </div>
  );
}
