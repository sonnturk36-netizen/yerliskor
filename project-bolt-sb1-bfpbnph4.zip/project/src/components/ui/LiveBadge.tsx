import type { Match } from '../../types';

interface LiveBadgeProps {
  match: Match;
}

export function LiveBadge({ match }: LiveBadgeProps) {
  const { statusShort, minute, extraTimeMinute, kickoffTime } = match;

  // Scheduled — show kickoff time
  if (statusShort === 'NS' || statusShort === 'TBD' || match.status === 'scheduled') {
    const time = kickoffTime ? formatKickoffTime(kickoffTime) : '';
    return (
      <span className="live-badge" style={{
        background: 'rgba(34,34,34,0.07)',
        color: 'var(--text-secondary)',
        fontSize: 11,
        fontWeight: 600,
        padding: '3px 10px',
        borderRadius: 6,
        whiteSpace: 'nowrap',
      }}>
        {time ? `Başlayacak • ${time}` : 'Başlayacak'}
      </span>
    );
  }

  // Half time
  if (statusShort === 'HT') {
    return (
      <span className="live-badge live-badge--ht">
        Devre Arası
      </span>
    );
  }

  // Extra time break
  if (statusShort === 'BT') {
    return (
      <span className="live-badge live-badge--ht">
        Uzatma Arası
      </span>
    );
  }

  // Penalty shootout
  if (statusShort === 'P') {
    return (
      <span className="live-badge live-badge--live">
        <span className="live-dot" style={{ width: 6, height: 6 }} />
        Penaltılar
      </span>
    );
  }

  // Extra time live
  if (statusShort === 'ET') {
    const display = extraTimeMinute
      ? `${minute}+${extraTimeMinute}'`
      : `${minute}'`;
    return (
      <span className="live-badge live-badge--live">
        <span className="live-dot" style={{ width: 6, height: 6 }} />
        Uzatmalar • {display}
      </span>
    );
  }

  // Live (1H or 2H)
  if (statusShort === '1H' || statusShort === '2H' || statusShort === 'LIVE') {
    const display = extraTimeMinute
      ? `${minute}+${extraTimeMinute}'`
      : `${minute}'`;
    return (
      <span className="live-badge live-badge--live">
        <span className="live-dot" style={{ width: 6, height: 6 }} />
        CANLI • {display}
      </span>
    );
  }

  // Finished variants
  if (statusShort === 'FT') return <span className="live-badge live-badge--ft">Bitti</span>;
  if (statusShort === 'AET') return <span className="live-badge live-badge--ft">Bitti (UZ)</span>;
  if (statusShort === 'PEN') return <span className="live-badge live-badge--ft">Bitti (PEN)</span>;
  if (statusShort === 'AWD' || statusShort === 'WO') return <span className="live-badge live-badge--ft">Hükmen</span>;
  if (match.status === 'finished') return <span className="live-badge live-badge--ft">Bitti</span>;

  // Problem statuses
  if (statusShort === 'PST') return <span className="live-badge live-badge--ft">Ertelendi</span>;
  if (statusShort === 'CANC') return <span className="live-badge live-badge--ft">İptal</span>;
  if (statusShort === 'ABD') return <span className="live-badge live-badge--ft">Yarıda Kaldı</span>;
  if (statusShort === 'SUSP' || statusShort === 'INT') return <span className="live-badge live-badge--ft">Durduruldu</span>;
  if (statusShort === 'DEL') return <span className="live-badge live-badge--ft">Gecikmeli</span>;
  if (match.status === 'postponed') return <span className="live-badge live-badge--ft">Ertelendi</span>;

  return <span className="live-badge live-badge--ft">—</span>;
}

/** Format ISO date string to Turkish 24-hour time in Istanbul timezone */
function formatKickoffTime(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString('tr-TR', {
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'Europe/Istanbul',
      hour12: false,
    });
  } catch {
    return '';
  }
}
