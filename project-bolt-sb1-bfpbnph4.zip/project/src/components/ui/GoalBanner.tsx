import { useEffect, useState } from 'react';

interface GoalBannerProps {
  homeTeam: string;
  awayTeam: string;
  scorer: string;
  minute: number;
  score: string;
  onDismiss: () => void;
}

export function GoalBanner({ homeTeam, awayTeam, scorer, minute, score, onDismiss }: GoalBannerProps) {
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const dismiss = setTimeout(() => {
      setExiting(true);
      setTimeout(onDismiss, 350);
    }, 4000);
    return () => clearTimeout(dismiss);
  }, [onDismiss]);

  return (
    <div
      className={exiting ? 'goal-banner-exit' : 'goal-banner-enter'}
      style={{
        position: 'fixed',
        top: 0, left: '50%',
        transform: 'translateX(-50%)',
        width: '100%',
        maxWidth: 480,
        zIndex: 999,
        background: 'linear-gradient(135deg, #B71C1C 0%, #D50000 100%)',
        color: '#fff',
        padding: '12px 18px',
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        boxShadow: '0 4px 20px rgba(213,0,0,0.45)',
        cursor: 'pointer',
      }}
      onClick={() => { setExiting(true); setTimeout(onDismiss, 350); }}
    >
      <span style={{ fontSize: 28, lineHeight: 1, flexShrink: 0 }}>⚽</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 17, fontWeight: 800, letterSpacing: 1, lineHeight: 1 }}>
          GOOOL!
        </div>
        <div style={{ fontSize: 12.5, fontWeight: 600, opacity: 0.92, marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {homeTeam} {score} {awayTeam}
        </div>
        <div style={{ fontSize: 11.5, opacity: 0.82, marginTop: 1 }}>
          {scorer} {minute}'
        </div>
      </div>
      <span style={{ fontSize: 18, opacity: 0.7, flexShrink: 0 }}>✕</span>
    </div>
  );
}
