/// <reference types="vite/client" />

export const TURKISH_LEAGUES: Record<number, string> = {
  203: 'Trendyol Süper Lig',
  204: 'Trendyol 1. Lig',
  205: 'TFF 2. Lig',
  206: 'TFF 3. Lig',
  207: 'Ziraat Türkiye Kupası',
};

export const TURKISH_LEAGUE_IDS = [203, 204, 205, 206, 207];

/** Display order for competition headings */
export const LEAGUE_ORDER: Record<number, number> = {
  203: 1,
  204: 2,
  205: 3,
  206: 4,
  207: 5,
};

/** CSS variable name for each league's accent color */
export function leagueAccent(leagueId: number): string {
  switch (leagueId) {
    case 203: return 'var(--league-superlig)';
    case 204: return 'var(--league-1lig)';
    case 205: return 'var(--league-2lig)';
    case 206: return 'var(--league-3lig)';
    case 207: return 'var(--league-cup)';
    default:  return 'var(--league-default)';
  }
}

/** Small emoji badge for competition heading */
export function leagueEmoji(leagueId: number): string {
  switch (leagueId) {
    case 203: return '🔴';
    case 204: return '🔵';
    case 205: return '🟠';
    case 206: return '🟢';
    case 207: return '🏆';
    default:  return '⚽';
  }
}

export const API_BASE = 'https://v3.football.api-sports.io';

export const POLL_INTERVAL_MS = 30_000;

export function getApiKey(): string {
  return import.meta.env.VITE_API_FOOTBALL_KEY ?? '';
}

export function isApiKeyConfigured(): boolean {
  const key = getApiKey();
  return key.length > 0 && key !== 'YOUR_API_KEY_HERE';
}

export function getCurrentSeason(): number {
  const now = new Date();
  return now.getMonth() >= 6 ? now.getFullYear() : now.getFullYear() - 1;
}
