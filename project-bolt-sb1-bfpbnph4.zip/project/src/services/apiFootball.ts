import type { Match, MatchEvent, Player, MatchStatus, EventType } from '../types';
import { API_BASE, getApiKey, getCurrentSeason, TURKISH_LEAGUE_IDS } from './config';

function apiHeaders(): HeadersInit {
  return { 'x-apisports-key': getApiKey() };
}

async function apiFetch(endpoint: string, params: Record<string, string>): Promise<unknown> {
  const url = new URL(`${API_BASE}${endpoint}`);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));

  let lastError: Error | null = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const res = await fetch(url.toString(), {
        headers: apiHeaders(),
        signal: AbortSignal.timeout(15_000),
      });
      if (res.status === 429) {
        await new Promise(r => setTimeout(r, 5000 * (attempt + 1)));
        continue;
      }
      if (!res.ok) throw new Error(`API error: ${res.status}`);
      const data = await res.json() as { response: unknown[] };
      return data;
    } catch (e) {
      lastError = e as Error;
      if (attempt < 2) await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
    }
  }
  throw lastError;
}

function mapStatus(short: string): MatchStatus {
  switch (short) {
    case '1H': case '2H': case 'LIVE': case 'ET': case 'P': case 'BT': return 'live';
    case 'HT': return 'halftime';
    case 'FT': case 'AET': case 'PEN': case 'AWD': case 'WO': return 'finished';
    case 'PST': case 'CANC': case 'ABD': case 'SUSP': case 'INT': case 'DEL': return 'postponed';
    default: return 'scheduled';
  }
}

function shortName(name: string): string {
  const words = name.trim().split(/\s+/);
  if (words.length >= 2) return words.slice(0, 3).map(w => w[0].toUpperCase()).join('');
  return name.substring(0, 3).toUpperCase();
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function fixtureToMatch(f: any): Match {
  const fixture = f.fixture;
  const league = f.league;
  const teams = f.teams;
  const goals = f.goals;
  const venue = fixture.venue;
  const status = fixture.status;
  const short: string = status.short ?? 'NS';
  const matchStatus = mapStatus(short);

  const isStarted = short !== 'NS' && short !== 'TBD' && matchStatus !== 'scheduled';

  return {
    id: String(fixture.id),
    homeTeam: {
      id: String(teams.home.id),
      name: teams.home.name,
      shortName: shortName(teams.home.name),
      logoUrl: teams.home.logo ?? undefined,
    },
    awayTeam: {
      id: String(teams.away.id),
      name: teams.away.name,
      shortName: shortName(teams.away.name),
      logoUrl: teams.away.logo ?? undefined,
    },
    homeScore: isStarted ? (goals.home ?? 0) : null,
    awayScore: isStarted ? (goals.away ?? 0) : null,
    status: matchStatus,
    statusShort: short,
    minute: status.elapsed ?? 0,
    referee: fixture.referee ?? undefined,
    stadium: venue ? `${venue.name}${venue.city ? ', ' + venue.city : ''}` : undefined,
    competition: league.name,
    leagueId: league.id,
    round: league.round ?? undefined,
    kickoffTime: fixture.date ?? undefined,
    events: [],
    homeStartingXI: [],
    awayStartingXI: [],
    homeBench: [],
    awayBench: [],
  };
}

function isoDate(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

async function fetchForDate(dateStr: string): Promise<Match[]> {
  const season = getCurrentSeason();
  const results: Match[] = [];
  await Promise.allSettled(
    TURKISH_LEAGUE_IDS.map(async (lid) => {
      try {
        const data = await apiFetch('/fixtures', {
          league: String(lid), season: String(season),
          date: dateStr, timezone: 'Europe/Istanbul',
        }) as { response: unknown[] };
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        results.push(...(data.response as any[]).map(fixtureToMatch));
      } catch { /* skip */ }
    })
  );
  return results;
}

/** Today's fixtures */
export async function fetchTodayMatches(date?: Date): Promise<Match[]> {
  return fetchForDate(isoDate(date ?? new Date()));
}

/** Live fixtures across all Turkish leagues */
export async function fetchLiveMatches(): Promise<Match[]> {
  const results: Match[] = [];
  await Promise.allSettled(
    TURKISH_LEAGUE_IDS.map(async (lid) => {
      try {
        const data = await apiFetch('/fixtures', {
          league: String(lid), live: 'all', timezone: 'Europe/Istanbul',
        }) as { response: unknown[] };
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        results.push(...(data.response as any[]).map(fixtureToMatch));
      } catch { /* skip */ }
    })
  );
  return results;
}

/**
 * Past matches: fetch the `daysBack` most recent days.
 * Returns matches sorted newest → oldest.
 */
export async function fetchPastMatches(daysBack = 7): Promise<Match[]> {
  const today = new Date();
  const results: Match[] = [];

  for (let d = 1; d <= daysBack; d++) {
    const date = new Date(today);
    date.setDate(today.getDate() - d);
    const dayMatches = await fetchForDate(isoDate(date));
    results.push(...dayMatches);
  }

  // Sort newest first
  results.sort((a, b) => (b.kickoffTime ?? '').localeCompare(a.kickoffTime ?? ''));
  return results;
}

/**
 * Future matches: fetch the next `daysAhead` days.
 * Returns matches sorted by kickoff time ascending.
 */
export async function fetchFutureMatches(daysAhead = 7): Promise<Match[]> {
  const today = new Date();
  const results: Match[] = [];

  for (let d = 1; d <= daysAhead; d++) {
    const date = new Date(today);
    date.setDate(today.getDate() + d);
    const dayMatches = await fetchForDate(isoDate(date));
    results.push(...dayMatches);
  }

  results.sort((a, b) => (a.kickoffTime ?? '').localeCompare(b.kickoffTime ?? ''));
  return results;
}

/** Full match detail including events + lineups */
export async function fetchMatchDetails(id: string): Promise<Match | null> {
  try {
    const [fixtureData, eventsData, lineupsData] = await Promise.all([
      apiFetch('/fixtures', { id }) as Promise<{ response: unknown[] }>,
      apiFetch('/fixtures/events', { fixture: id }) as Promise<{ response: unknown[] }>,
      apiFetch('/fixtures/lineups', { fixture: id }) as Promise<{ response: unknown[] }>,
    ]);

    if (!fixtureData.response.length) return null;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const match = fixtureToMatch((fixtureData.response as any[])[0]);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    match.events = (eventsData.response as any[]).map((e: any): MatchEvent => {
      let type: EventType = 'goal';
      if (e.type === 'Card') type = e.detail === 'Red Card' ? 'redCard' : 'yellowCard';
      else if (e.type === 'subst') type = 'substitution';
      else if (e.type === 'Var') type = 'varDecision';
      return {
        id: `${id}_${e.time.elapsed}_${e.type}_${e.player?.name ?? ''}`,
        minute: e.time.elapsed,
        extraTime: e.time.extra ?? undefined,
        type, teamId: String(e.team.id),
        playerName: e.player?.name ?? '',
        assistPlayerName: e.assist?.name ?? undefined,
        replacedByPlayerName: e.type === 'subst' ? (e.assist?.name ?? undefined) : undefined,
        detail: e.detail,
      };
    });

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (lineupsData.response as any[]).forEach((lineup: any) => {
      const teamId = String(lineup.team.id);
      const mapPlayer = (p: { player: { id: number; name: string; number: number; pos: string; photo?: string } }): Player => ({
        id: String(p.player.id), name: p.player.name,
        number: p.player.number, position: mapPos(p.player.pos), photoUrl: p.player.photo,
      });
      const starters: Player[] = (lineup.startXI ?? []).map(mapPlayer);
      const subs: Player[] = (lineup.substitutes ?? []).map(mapPlayer);
      if (teamId === match.homeTeam.id) {
        match.homeStartingXI = starters; match.homeBench = subs;
      } else {
        match.awayStartingXI = starters; match.awayBench = subs;
      }
    });

    return match;
  } catch { return null; }
}

function mapPos(pos: string): string {
  switch (pos) {
    case 'GK': return 'Kaleci'; case 'DF': return 'Defans';
    case 'MF': return 'Orta Saha'; case 'FW': return 'Forvet';
    default: return 'Yedek';
  }
}
