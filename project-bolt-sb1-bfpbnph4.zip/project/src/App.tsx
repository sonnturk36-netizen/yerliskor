import { useState, useEffect } from 'react';
import { useMatchStore } from './store/matches';
import { useNotificationStore } from './store/notifications';
import { useMatchPolling } from './hooks/useMatchPolling';
import { AppBar } from './components/layout/AppBar';
import { YerliSkorIcon } from './components/layout/BrandLogo';
import { BottomNav } from './components/layout/BottomNav';
import { MatchesScreen } from './components/matches/MatchesScreen';
import { MatchDetailsScreen } from './components/match-details/MatchDetailsScreen';
import { NotificationsScreen } from './components/notifications/NotificationsScreen';
import { GoalBanner } from './components/ui/GoalBanner';
import type { Match } from './types';

type Tab = 'matches' | 'notifications';

function SplashScreen({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 1800);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div
      style={{
        position: 'fixed', inset: 0, background: 'var(--bg)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        gap: 20, zIndex: 100,
      }}
      className="animate-fade-in"
    >
      <div className="animate-scale-in" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20 }}>
        <div style={{
          width: 88, height: 88,
          borderRadius: 24,
          overflow: 'hidden',
          boxShadow: '0 8px 28px rgba(213,0,0,0.38)',
          background: '#D50000',
        }}>
          <YerliSkorIcon size={88} />
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 36, fontWeight: 700, letterSpacing: -0.5 }}>
            <span style={{ color: 'var(--text)' }}>Yerli</span>
            <span style={{ color: 'var(--primary)' }}>Skor</span>
          </div>
          <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 6 }}>
            Türk Futbolunun Skor Uygulaması
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [splash, setSplash] = useState(true);
  const [tab, setTab] = useState<Tab>('matches');
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);

  const matches = useMatchStore(s => s.matches);
  const goalBanner = useMatchStore(s => s.goalBanner);
  const setGoalBanner = useMatchStore(s => s.setGoalBanner);
  const unreadCount = useNotificationStore(s => s.unreadCount());

  useMatchPolling();

  const liveCount = matches.filter(m =>
    m.statusShort === '1H' || m.statusShort === '2H' ||
    m.statusShort === 'ET' || m.statusShort === 'P' || m.statusShort === 'LIVE'
  ).length;

  if (splash) {
    return <SplashScreen onDone={() => setSplash(false)} />;
  }

  if (selectedMatch) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100dvh' }}>
        {goalBanner && (
          <GoalBanner
            {...goalBanner}
            onDismiss={() => setGoalBanner(null)}
          />
        )}
        <MatchDetailsScreen match={selectedMatch} onBack={() => setSelectedMatch(null)} />
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100dvh' }}>
      {goalBanner && (
        <GoalBanner
          {...goalBanner}
          onDismiss={() => setGoalBanner(null)}
        />
      )}
      <AppBar liveCount={liveCount} />
      <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: tab === 'matches' ? 'flex' : 'none', flex: 1, flexDirection: 'column', overflow: 'hidden' }}>
          <MatchesScreen onMatchClick={setSelectedMatch} />
        </div>
        <div style={{ display: tab === 'notifications' ? 'flex' : 'none', flex: 1, flexDirection: 'column', overflow: 'hidden' }}>
          <NotificationsScreen />
        </div>
      </div>
      <BottomNav activeTab={tab} onTabChange={setTab} unreadCount={unreadCount} />
    </div>
  );
}
