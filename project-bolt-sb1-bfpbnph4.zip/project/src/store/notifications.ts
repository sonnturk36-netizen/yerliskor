import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { AppNotification, NotificationType } from '../types';

interface NotificationStore {
  notifications: AppNotification[];
  addNotification: (type: NotificationType, title: string, body: string, matchId?: string) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  clearAll: () => void;
  unreadCount: () => number;
}

export const useNotificationStore = create<NotificationStore>()(
  persist(
    (set, get) => ({
      notifications: [],

      addNotification(type, title, body, matchId) {
        const notif: AppNotification = {
          id: `${Date.now()}_${Math.random().toString(36).slice(2)}`,
          type,
          title,
          body,
          matchId,
          timestamp: new Date().toISOString(),
          read: false,
        };
        set(s => ({ notifications: [notif, ...s.notifications].slice(0, 100) }));
      },

      markAsRead(id) {
        set(s => ({
          notifications: s.notifications.map(n => n.id === id ? { ...n, read: true } : n),
        }));
      },

      markAllAsRead() {
        set(s => ({
          notifications: s.notifications.map(n => ({ ...n, read: true })),
        }));
      },

      clearAll() {
        set({ notifications: [] });
      },

      unreadCount() {
        return get().notifications.filter(n => !n.read).length;
      },
    }),
    { name: 'yerliskor-notifications' }
  )
);
