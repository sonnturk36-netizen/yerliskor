import { create } from 'zustand';
import type { Match } from '../types';
import { todayIstanbul, offsetDate } from '../services/dateUtils';

export type DateFilter = 'past' | 'today' | 'future';

interface MatchStore {
  // Today's matches (live + today)
  matches: Match[];
  loading: boolean;
  error: string | null;

  // Past matches (previous days)
  pastMatches: Match[];
  pastLoading: boolean;
  pastLoadedDays: number;

  // Future matches (upcoming days)
  futureMatches: Match[];
  futureLoading: boolean;
  futureLoadedDays: number;

  // Active date filter
  dateFilter: DateFilter;
  /** Selected day chip (YYYY-MM-DD) — within the current filter's date range */
  selectedDay: string;

  // Goal banner
  goalBanner: { homeTeam: string; awayTeam: string; scorer: string; minute: number; score: string } | null;

  setMatches: (m: Match[]) => void;
  setLoading: (v: boolean) => void;
  setError: (e: string | null) => void;

  setPastMatches: (m: Match[]) => void;
  setPastLoading: (v: boolean) => void;
  appendPastMatches: (m: Match[]) => void;
  setPastLoadedDays: (n: number) => void;

  setFutureMatches: (m: Match[]) => void;
  setFutureLoading: (v: boolean) => void;
  appendFutureMatches: (m: Match[]) => void;
  setFutureLoadedDays: (n: number) => void;

  setDateFilter: (f: DateFilter) => void;
  setSelectedDay: (d: string) => void;

  setGoalBanner: (b: MatchStore['goalBanner']) => void;
}

export const useMatchStore = create<MatchStore>((set) => ({
  matches: [],
  loading: false,
  error: null,
  pastMatches: [],
  pastLoading: false,
  pastLoadedDays: 0,
  futureMatches: [],
  futureLoading: false,
  futureLoadedDays: 0,
  dateFilter: 'today',
  selectedDay: todayIstanbul(),
  goalBanner: null,

  setMatches: (matches) => set({ matches, loading: false, error: null }),
  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error, loading: false }),

  setPastMatches: (pastMatches) => set({ pastMatches, pastLoading: false }),
  setPastLoading: (pastLoading) => set({ pastLoading }),
  appendPastMatches: (more) => set(s => ({ pastMatches: [...s.pastMatches, ...more], pastLoading: false })),
  setPastLoadedDays: (n) => set({ pastLoadedDays: n }),

  setFutureMatches: (futureMatches) => set({ futureMatches, futureLoading: false }),
  setFutureLoading: (futureLoading) => set({ futureLoading }),
  appendFutureMatches: (more) => set(s => ({ futureMatches: [...s.futureMatches, ...more], futureLoading: false })),
  setFutureLoadedDays: (n) => set({ futureLoadedDays: n }),

  setDateFilter: (dateFilter) => {
    const today = todayIstanbul();
    const defaultDay = dateFilter === 'past'
      ? offsetDate(today, -1)
      : dateFilter === 'future'
        ? offsetDate(today, 1)
        : today;
    set({ dateFilter, selectedDay: defaultDay });
  },
  setSelectedDay: (selectedDay) => set({ selectedDay }),

  setGoalBanner: (goalBanner) => set({ goalBanner }),
}));
